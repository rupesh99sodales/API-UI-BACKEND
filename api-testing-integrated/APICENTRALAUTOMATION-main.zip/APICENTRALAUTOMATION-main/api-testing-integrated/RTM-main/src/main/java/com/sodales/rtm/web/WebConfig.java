package com.sodales.rtm.web;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Allows a browser-based frontend (dev servers below) to call the API.
 * exposedHeaders is what lets JavaScript read the download filename from
 * Content-Disposition. Tighten allowedOrigins to your real domains for prod.
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/api/**")
                .allowedOrigins(
                        "http://localhost:3000",   // React (CRA / Next dev)
                        "http://localhost:5173",   // Vite
                        "http://localhost:4200")   // Angular
                .allowedMethods("GET", "POST", "OPTIONS")
                .allowedHeaders("*")
                .exposedHeaders("Content-Disposition")
                .allowCredentials(false);
    }
}
