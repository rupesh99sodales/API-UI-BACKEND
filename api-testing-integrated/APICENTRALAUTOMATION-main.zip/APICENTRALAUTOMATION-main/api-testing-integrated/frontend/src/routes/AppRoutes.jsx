import { Routes, Route } from "react-router-dom";
import MainLayout from "../layouts/MainLayout";
import ApiTestingPage from "../pages/ApiTestingPage";
import TestcaseGenerator from "../pages/TestcaseGenerator";
import RTMGenerator from "../pages/RTMGenerator"
import Plugin from "../pages/Plugin"
import Converter from "../pages/Converter"
import PayloadEncryption from "../pages/PayloadEncryption"
// import SettingsPage from "../pages/RTMGenerator";
// import NotFoundPage from "../pages/NotFoundPage";

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<MainLayout />}>
        <Route index element={<ApiTestingPage />} />
        <Route path="api-testing" element={<ApiTestingPage />} />
        <Route path="testcase-generator" element={<TestcaseGenerator />} />
        <Route path="rtm-generator" element={<RTMGenerator />} />
        <Route path="plugin" element={<Plugin />} />
        <Route path="convert" element={<Converter />} />
         <Route path="payload-encrypt-decrypt" element={<PayloadEncryption />} />
      </Route>

      {/* <Route path="*" element={<NotFoundPage />} /> */}
    </Routes>
  );
}
