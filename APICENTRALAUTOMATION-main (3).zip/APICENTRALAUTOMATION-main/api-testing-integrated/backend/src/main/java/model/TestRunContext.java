package model;

public class TestRunContext {
    public String runId;
    public String runDir;
    public String excelPath;
    public String htmlPath;
    public String extentPath;
    public String csvPath;
    public boolean reportPortalEnabled;
    public String projectName;
    // public String logPath;
}
