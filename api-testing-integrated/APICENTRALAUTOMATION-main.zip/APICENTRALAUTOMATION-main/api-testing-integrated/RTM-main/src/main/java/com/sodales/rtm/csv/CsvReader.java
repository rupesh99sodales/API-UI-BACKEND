package com.sodales.rtm.csv;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Small dependency-free CSV parser (RFC 4180 style). Handles quoted fields,
 * embedded commas and newlines, escaped double-quotes (""), CRLF endings, and a
 * leading UTF-8 BOM (Azure DevOps exports one). Row keys are lower-cased headers.
 *
 * Reads the whole stream into memory first — fine for ADO exports (20 MB cap).
 */
public final class CsvReader {

    private CsvReader() { }

    public static CsvTable read(InputStream in) throws IOException {
        String content = readAll(in);
        List<List<String>> records = parse(content);
        return toTable(records);
    }

    private static String readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) != -1) bos.write(buf, 0, n);
        String s = bos.toString(StandardCharsets.UTF_8);
        if (!s.isEmpty() && s.charAt(0) == '\uFEFF') s = s.substring(1); // strip BOM
        return s;
    }

    static List<List<String>> parse(String content) {
        List<List<String>> records = new ArrayList<>();
        List<String> record = new ArrayList<>();
        StringBuilder field = new StringBuilder();
        boolean inQuotes = false;

        for (int i = 0; i < content.length(); i++) {
            char c = content.charAt(i);
            if (inQuotes) {
                if (c == '"') {
                    if (i + 1 < content.length() && content.charAt(i + 1) == '"') {
                        field.append('"');
                        i++;
                    } else {
                        inQuotes = false;
                    }
                } else {
                    field.append(c);
                }
            } else {
                switch (c) {
                    case '"' -> inQuotes = true;
                    case ',' -> { record.add(field.toString()); field.setLength(0); }
                    case '\r' -> { /* ignore, handled by \n */ }
                    case '\n' -> {
                        record.add(field.toString());
                        field.setLength(0);
                        records.add(record);
                        record = new ArrayList<>();
                    }
                    default -> field.append(c);
                }
            }
        }
        // trailing field / record (file may not end with newline)
        if (field.length() > 0 || !record.isEmpty()) {
            record.add(field.toString());
            records.add(record);
        }
        return records;
    }

    private static CsvTable toTable(List<List<String>> records) {
        List<String> headers = new ArrayList<>();
        List<Map<String, String>> rows = new ArrayList<>();
        if (records.isEmpty()) return new CsvTable(headers, rows);

        for (String h : records.get(0)) headers.add(h == null ? "" : h.trim());

        for (int r = 1; r < records.size(); r++) {
            List<String> rec = records.get(r);
            if (rec.size() == 1 && (rec.get(0) == null || rec.get(0).isBlank())) continue; // blank line
            Map<String, String> row = new HashMap<>();
            for (int i = 0; i < headers.size(); i++) {
                String v = i < rec.size() ? rec.get(i) : null;
                row.put(headers.get(i).toLowerCase(), v == null ? null : v.trim());
            }
            rows.add(row);
        }
        return new CsvTable(headers, rows);
    }
}
