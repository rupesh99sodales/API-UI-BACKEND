import pandas as pd
import uuid
import json
import os

from urllib.parse import urlparse

from fastapi import FastAPI, UploadFile, File, Form
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware


app = FastAPI()


# Allow React Vite frontend access
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "*"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


DOWNLOAD_FOLDER = "downloads"

os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)


# -----------------------------
# URL Parser
# -----------------------------

def build_url_object(raw_url):

    parsed = urlparse(str(raw_url))

    return {
        "raw": raw_url,
        "protocol": parsed.scheme,
        "host": parsed.hostname.split(".")
            if parsed.hostname else [],

        "path": parsed.path.strip("/").split("/")
            if parsed.path else [],

        "query": [
            {
                "key": k,
                "value": v
            }
            for k, v in [
                q.split("=", 1)
                for q in parsed.query.split("&")
                if "=" in q
            ]
        ] if parsed.query else []
    }



# -----------------------------
# Header Parser
# -----------------------------

def parse_headers(headers_raw):

    headers = []

    if pd.isna(headers_raw):
        return headers


    for header in str(headers_raw).split(","):

        if ":" in header:

            key, value = header.split(":", 1)

            headers.append({
                "key": key.strip(),
                "value": value.strip(),
                "type": "text"
            })


    return headers



# -----------------------------
# Excel -> Postman Converter
# -----------------------------

def convert_excel_to_postman_df(
        df,
        collection_name="Generated from Excel"
):

    collection = {

        "info": {
            "name": collection_name,
            "_postman_id": str(uuid.uuid4()),

            "schema":
            "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
        },

        "item": []
    }


    VALID_METHODS = {
        "GET",
        "POST",
        "PUT",
        "DELETE",
        "PATCH",
        "OPTIONS",
        "HEAD"
    }


    errors = []


    for index, row in df.iterrows():

        excel_row_number = index + 2


        test_name = str(
            row.get(
                "TestName",
                "Unnamed Request"
            )
        ).strip()


        method = str(
            row.get(
                "Method",
                "GET"
            )
        ).upper().strip()


        url = row.get(
            "URL",
            ""
        )


        headers = parse_headers(
            row.get("Headers")
        )


        payload = row.get(
            "Payload"
        )


        # Validation

        if method not in VALID_METHODS:

            errors.append(
                f"Row {excel_row_number} ({test_name}) - Invalid HTTP method '{method}'"
            )


        if pd.isna(url) or str(url).strip() == "":

            errors.append(
                f"Row {excel_row_number} ({test_name}) - URL cannot be blank"
            )


        if method in {
            "POST",
            "PUT",
            "PATCH"
        }:

            if pd.isna(payload) or str(payload).strip() == "":

                errors.append(
                    f"Row {excel_row_number} ({test_name}) - Payload required for {method}"
                )


        if any(
            f"Row {excel_row_number}" in error
            for error in errors
        ):
            continue



        request_item = {

            "name": test_name,

            "request": {

                "method": method,

                "header": headers,

                "url": build_url_object(url)
            }
        }



        if method in {
            "POST",
            "PUT",
            "PATCH"
        }:

            request_item["request"]["body"] = {

                "mode": "raw",

                "raw": str(payload),

                "options": {

                    "raw": {
                        "language": "json"
                    }
                }
            }



        collection["item"].append(
            request_item
        )



    if errors:

        return None, errors


    return collection, None

# -----------------------------
# Postman -> Excel
# -----------------------------

def headers_to_string(headers):
    """
    Convert Postman header array to:
    Content-Type: application/json, Authorization: Bearer xxx
    """
    if not headers:
        return ""

    return ", ".join(
        f"{h.get('key','')}: {h.get('value','')}"
        for h in headers
    )


def formdata_to_string(formdata):
    """
    Convert form-data list into readable string.
    """
    if not formdata:
        return "", ""

    values = []
    file_path = ""

    for item in formdata:

        if item.get("type") == "file":
            file_path = item.get("src", "")
            values.append(f"{item['key']}=<FILE>")

        else:
            values.append(f"{item['key']}={item.get('value','')}")

    return ", ".join(values), file_path


def build_raw_url(url):

    if isinstance(url, str):
        return url

    if isinstance(url, dict):

        if url.get("raw"):
            return url["raw"]

        protocol = url.get("protocol", "http")
        host = ".".join(url.get("host", []))
        path = "/".join(url.get("path", []))

        raw = f"{protocol}://{host}"

        if path:
            raw += "/" + path

        query = url.get("query", [])

        if query:
            q = "&".join(
                f"{x['key']}={x['value']}"
                for x in query
            )
            raw += "?" + q

        return raw

    return ""


def convert_postman_to_template(collection):

    rows = []

    items = collection.get("item", [])

    for item in items:

        request = item.get("request", {})

        body = request.get("body", {})

        body_type = ""
        payload = ""
        form_data = ""
        file_path = ""

        if body:

            mode = body.get("mode", "")

            body_type = mode

            if mode == "raw":

                payload = body.get("raw", "")

            elif mode == "formdata":

                form_data, file_path = formdata_to_string(
                    body.get("formdata", [])
                )

            elif mode == "urlencoded":

                form_data = ", ".join(
                    f"{x['key']}={x.get('value','')}"
                    for x in body.get("urlencoded", [])
                )

        rows.append({

            "TestName":
                item.get("name", ""),

            "Method":
                request.get("method", ""),

            "URL":
                build_raw_url(request.get("url")),

            "Headers":
                headers_to_string(
                    request.get("header", [])
                ),

            "BodyType":
                body_type,

            "Payload":
                payload,

            "FormData":
                form_data,

            "FilePath":
                file_path,

            "ExpectedStatus":
                "",

            "ExpectedResponseContains":
                "",

            "Skip?":
                "",

            "GlobalVariableJsonorXMLPath":
                "",

            "GlobalVariable":
                "",

            "JsonorXML":
                ""
        })

    return pd.DataFrame(rows)



# -----------------------------
# API Endpoint
# -----------------------------

@app.post("/convert")
async def convert_excel(

    file: UploadFile = File(...),

    collectionName: str = Form(
        "Generated from Excel"
    )
):


    # Read Excel uploaded from React

    df = pd.read_excel(
        file.file
    )


    collection, errors = convert_excel_to_postman_df(

        df,

        collectionName
    )


    if errors:

        return {
            "success": False,
            "errors": errors
        }



    file_name = "collection.json"


    file_path = os.path.join(
        DOWNLOAD_FOLDER,
        file_name
    )


    with open(
        file_path,
        "w"
    ) as f:

        json.dump(
            collection,
            f,
            indent=4
        )



    return {

        "success": True,

        "message": "Postman collection generated",

        "downloadUrl":
        "http://localhost:7979/download/collection.json"
    }

@app.post("/postman-to-template")
async def postman_to_template(file: UploadFile = File(...)):

    collection = json.load(file.file)

    df = convert_postman_to_template(collection)

    output_path = os.path.join(
        DOWNLOAD_FOLDER,
        "Template.xlsx"
    )

    df.to_excel(output_path, index=False)

    return {
        "success": True,
        "message": "Template generated successfully",
        "downloadUrl": "http://localhost:7979/download/Template.xlsx"
    }

# -----------------------------
# Download Endpoint
# -----------------------------

@app.get("/download/collection.json")
def download_collection():

    return FileResponse(

        path="downloads/collection.json",

        filename="collection.json",

        media_type="application/json"
    )
@app.get("/download/Template.xlsx")
def download_template():

    return FileResponse(
        path="downloads/Template.xlsx",
        filename="Template.xlsx",
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )


# -----------------------------
# Health Check
# -----------------------------

@app.get("/")
def home():

    return {
        "status": "API Template to Postman Converter Running"
    }
