package org.sodales;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Instant;
import java.util.Properties;
import java.util.List;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class ReportPortalManager {

    private static final HttpClient client = HttpClient.newHttpClient();

    private static final ObjectMapper mapper = new ObjectMapper();

    private static String launchId;
    private static String testItemId;

    private static String ENDPOINT;
    private static String API_KEY;
    private static String PROJECT;
    private static String LAUNCH_NAME;

    static {
        loadConfiguration();
    }

    /**
     * Load ReportPortal configuration from
     * src/main/resources/reportportal.properties
     */
    private static void loadConfiguration() {

        try (InputStream input = ReportPortalManager.class.getClassLoader().getResourceAsStream("reportportal.properties")) {

            if (input == null) {
               
            	throw new RuntimeException("reportportal.properties not found in classpath");
            }

            Properties properties = new Properties();
            properties.load(input);

            ENDPOINT = properties.getProperty("rp.endpoint");
            API_KEY = properties.getProperty("rp.api.key");
            PROJECT = properties.getProperty("rp.project");
            LAUNCH_NAME = properties.getProperty("rp.launch");

            System.out.println("ReportPortal configuration loaded.");

            validateConfiguration();

        } catch (IOException e) {

            throw new RuntimeException("Failed to load ReportPortal configuration", e);
        }
    }

    /**
     * Validate required ReportPortal configuration.
     */
    private static void validateConfiguration() {

        if (isBlank(ENDPOINT)) {
            throw new RuntimeException("rp.endpoint is missing in reportportal.properties");
        }

        if (isBlank(API_KEY)) {
            throw new RuntimeException("rp.api.key is missing in reportportal.properties");
        }

        if (isBlank(PROJECT)) {
            throw new RuntimeException("rp.project is missing in reportportal.properties");
        }

        if (isBlank(LAUNCH_NAME)) {
            throw new RuntimeException("rp.launch is missing in reportportal.properties");
        }

        ENDPOINT = removeTrailingSlash(ENDPOINT);
    }

    
     // Print current ReportPortal configuration.
     
    public static void testConfiguration() {

        System.out.println("ReportPortal Endpoint : " + ENDPOINT);

        System.out.println("Project : " + PROJECT);

        System.out.println("Launch Name : " + LAUNCH_NAME);
    }

   
     //Create a new ReportPortal launch.
    
    public static void startLaunch() {

        try {

            // Reset previous run information.
            launchId = null;
            testItemId = null;

            ObjectNode launch = mapper.createObjectNode();

            launch.put("name",LAUNCH_NAME);

            launch.put("description","QUALITY API Automation Run");

            launch.put("mode","DEFAULT");

            launch.put("startTime",Instant.now().toString());

            String requestBody =mapper.writeValueAsString(launch);

            HttpRequest request = HttpRequest.newBuilder().uri(URI.create(ENDPOINT + "/api/v1/" + PROJECT + "/launch"))
                            .header("Authorization","Bearer " + API_KEY).header("Content-Type","application/json")
                            .POST(HttpRequest.BodyPublishers.ofString(requestBody)).build();

            HttpResponse<String> response = client.send(request,HttpResponse.BodyHandlers.ofString());

            System.out.println("ReportPortal Launch Status : " + response.statusCode());

            System.out.println("ReportPortal Launch Response : " + response.body());

            if (response.statusCode() >= 200
                    && response.statusCode() < 300) {

                JsonNode json = mapper.readTree(response.body());

                if (json.has("id")) {

                    launchId = json.get("id").asText();

                    System.out.println("Launch ID : " + launchId);

                } else {

                    System.out.println("Launch created but launch ID was not returned.");
                }

            } else {

                System.out.println("Failed to create ReportPortal launch.");
            }

        } catch (Exception e) {

            System.out.println("Exception while creating ReportPortal launch:");

            e.printStackTrace();
        }
    }

    /**
     * Create a test item under the current launch.
     *
     * @param testName test case name
     * @return ReportPortal test item ID, or null if creation failed
     */
    public static String startTestItem(String testName) {

        try {

            if (launchId == null) {
                
            	System.out.println("Cannot create test item because launchId is null.");

                return null;
            }

            // Clear previous test item ID before creating a new one.
            testItemId = null;

            ObjectNode item = mapper.createObjectNode();

            item.put("name", safeValue(testName));

            item.put("description", "API Test");

            item.put("startTime", Instant.now().toString());

            item.put("type", "STEP");

            item.put("launchUuid", launchId);

            String requestBody = mapper.writeValueAsString(item);

            HttpRequest request = HttpRequest.newBuilder().uri(URI.create(ENDPOINT + "/api/v1/" + PROJECT + "/item"))
                            .header("Authorization", "Bearer " + API_KEY)
                            .header("Content-Type", "application/json")
                            .POST(HttpRequest.BodyPublishers.ofString(requestBody)).build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            System.out.println("Test Item Status : " + response.statusCode());

            System.out.println("Test Item Response : " + response.body());

            if (response.statusCode() >= 200
                    && response.statusCode() < 300) {

                JsonNode json = mapper.readTree(response.body());

                if (json.has("id")) {

                    testItemId = json.get("id").asText();

                    System.out.println("Test Item ID : " + testItemId);

                    return testItemId;
                }
            }

            System.out.println("Failed to create Test Item.");

        } catch (Exception e) {

            System.out.println("Exception while creating ReportPortal test item:");

            e.printStackTrace();
        }

        return null;
    }

    /**
     * Send an INFO log to the  ReportPortal test item.
     */
    public static void log(String message) {

        try {

            if (testItemId == null) {

                System.out.println("Cannot send log because testItemId is null.");

                return;
            }

            ObjectNode log = mapper.createObjectNode();
            log.put("itemUuid", testItemId);
            log.put("launchUuid", launchId);
            log.put("level", "INFO");
            log.put("time",Instant.now().toString());

            log.put("message", safeValue(message));

            String requestBody = mapper.writeValueAsString(log);

            HttpRequest request = HttpRequest.newBuilder().uri(URI.create(ENDPOINT + "/api/v1/" + PROJECT + "/log"))
                            .header("Authorization", "Bearer " + API_KEY)
                            .header("Content-Type", "application/json")
                            .POST(HttpRequest.BodyPublishers.ofString(requestBody)).build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            System.out.println("Log Status : " + response.statusCode());

            if (response.statusCode() < 200
                    || response.statusCode() >= 300) {

                System.out.println("ReportPortal Log Response : " + response.body());
            }

        } catch (Exception e) {

            System.out.println("Exception while sending ReportPortal log:");

            e.printStackTrace();
        }
    }

    /**
     * Finish the current test item.
     *
     * Supported statuses:
     * PASSED
     * FAILED
     * SKIPPED
     * STOPPED
     * CANCELLED
     *
     * For API testing use:
     * PASSED / FAILED
     */
    public static void finishTestItem(String status) {

        try {

            if (testItemId == null) {

                System.out.println("Cannot finish test item because testItemId is null.");

                return;
            }

            String finalStatus = normalizeStatus(status);

            ObjectNode finish = mapper.createObjectNode();

            finish.put("endTime", Instant.now().toString());

            finish.put("status", finalStatus);

            String requestBody = mapper.writeValueAsString(finish);

            System.out.println("Finishing Test Item : " + testItemId + " with status : " + finalStatus);

            HttpRequest request = HttpRequest.newBuilder().uri(URI.create(ENDPOINT + "/api/v1/" + PROJECT + "/item/" + testItemId))
                            .header("Authorization", "Bearer " + API_KEY)
                            .header("Content-Type", "application/json")
                            .PUT(HttpRequest.BodyPublishers.ofString(requestBody)).build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            System.out.println("Finish Test Item Status : " + response.statusCode());

            System.out.println("Finish Test Item Response : " + response.body());

            if (response.statusCode() >= 200
                    && response.statusCode() < 300) {

                System.out.println("ReportPortal test item finished successfully as " + finalStatus);

            } else {

                System.out.println("Failed to finish ReportPortal test item.");
            }

        } catch (Exception e) {

            System.out.println("Exception while finishing ReportPortal test item:");

            e.printStackTrace();
        }
    }

    /**
     * Finish the current ReportPortal launch.
     */
    public static void finishLaunch() {

        try {

            if (launchId == null) {

                System.out.println("Cannot finish launch because launchId is null.");

                return;
            }

            ObjectNode finish = mapper.createObjectNode();

            finish.put("endTime", Instant.now().toString());

            String requestBody = mapper.writeValueAsString(finish);

            HttpRequest request = HttpRequest.newBuilder().uri(URI.create(ENDPOINT + "/api/v1/" + PROJECT + "/launch/" + launchId + "/finish"))
            .header("Authorization", "Bearer " + API_KEY)
            .header("Content-Type", "application/json").PUT(HttpRequest.BodyPublishers.ofString(requestBody)).build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            System.out.println("Finish Launch Status : " + response.statusCode());

            System.out.println("Finish Launch Response : " + response.body());

            if (response.statusCode() >= 200
                    && response.statusCode() < 300) {

                System.out.println("ReportPortal launch finished successfully.");

            } else {

                System.out.println("Failed to finish ReportPortal launch.");
            }

        } catch (Exception e) {

            System.out.println("Exception while finishing ReportPortal launch:");

            e.printStackTrace();
        }
    }
    
    

    /**
     * Return current launch ID.
     */
    public static String getLaunchId() {
        return launchId;
    }

    /**
     * Return current test item ID.
     */
    public static String getTestItemId() {
        return testItemId;
    }
     
    public static List<String> getProjects() {

        try {

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(ENDPOINT + "/api/v1/project/names"))
                    .header("Authorization", "Bearer " + API_KEY)
                    .header("Content-Type", "application/json")
                    .GET()
                    .build();

            HttpResponse<String> response =
                    client.send(request, HttpResponse.BodyHandlers.ofString());

            System.out.println("ReportPortal Projects Status : " + response.statusCode());
            System.out.println("ReportPortal Projects Response : " + response.body());

            if (response.statusCode() >= 200
                    && response.statusCode() < 300) {

                JsonNode json = mapper.readTree(response.body());

                List<String> projectNames = new java.util.ArrayList<>();

                if (json.isArray()) {

                    for (JsonNode project : json) {
                        projectNames.add(project.asText());
                    }
                }

                return projectNames;
            }

            System.out.println("Failed to retrieve ReportPortal projects.");

        } catch (Exception e) {

            System.out.println("Exception while retrieving ReportPortal projects:");
            e.printStackTrace();
        }

        return new java.util.ArrayList<>();
    }


    //add project from UI
    
    public static boolean createProject(String projectName) {

        try {

        	ObjectNode project = mapper.createObjectNode();
        	project.put("projectName", projectName);
        	project.put("entryType", "INTERNAL");

            String requestBody = mapper.writeValueAsString(project);

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(ENDPOINT + "/api/v1/project"))
                    .header("Authorization", "Bearer " + API_KEY)
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                    .build();

            HttpResponse<String> response =
                    client.send(request, HttpResponse.BodyHandlers.ofString());

            System.out.println("Create ReportPortal Project Status : " + response.statusCode());
            System.out.println("Create ReportPortal Project Response : " + response.body());

            return response.statusCode() >= 200
                    && response.statusCode() < 300;

        } catch (Exception e) {

            System.out.println("Exception while creating ReportPortal project:");
            e.printStackTrace();

            return false;
        }
    }
    
    public static void setProject(String projectName) {
        if (projectName != null && !projectName.isBlank()) {
            PROJECT = projectName.trim();
        }
    }
    
    
    /**
     * Convert incoming status into a valid ReportPortal status.
     */
    private static String normalizeStatus(String status) {	

        if (status == null) {
            return "FAILED";
        }

        String normalized = status.trim().toUpperCase();

        switch (normalized) {

            case "PASSED":
                return "PASSED";

            case "FAILED":
                return "FAILED";

            case "SKIPPED":
                return "SKIPPED";

            case "STOPPED":
                return "STOPPED";

            case "CANCELLED":
                return "CANCELLED";

            default:
                System.out.println("Unknown ReportPortal status '" + status + "'. Using FAILED.");

                return "FAILED";
        }
    }

    private static String safeValue(String value) {

        return value == null ? "" : value;
    }

    private static boolean isBlank(String value) {

        return value == null || value.trim().isEmpty();
    }

    private static String removeTrailingSlash(String value) {

        if (value == null) {
            return null;
        }

        String result = value.trim();

        while (result.endsWith("/")) {
            result = result.substring(0, result.length() - 1);
        }

        return result;
    }
}