import React, { useMemo, useRef, useState, useEffect } from "react";
import "../styles/plugin.css";

const PLUGIN_DOCUMENTS = [
  {
    name: "Observer Plugin",
    url: "/docs/",
    // available: false,
  },
  {
    name: "Assessibility Extension",
    url: "/docs/",
    // available: true,
  },
];
const PLUGIN_EXTENSIONS = [
  {
    name: "Observer Plugin",
    gitUrl: "https://github.com/Sodales-Solutions/OBSERVER_Plugin.git",
  },
  {
    name: "Accessibility Extension",
    gitUrl: "https://github.com/your-org/accessibility-extension",
  },
  {
    name: "Automation Code Generator",
    gitUrl:
      "https://github.com/Sodales-Solutions/AUTOMATION_CODE_GENERATOR_JAVA.git",
  },
  {
    name: "Automation Framework Execution",
    gitUrl:
      "https://github.com/Sodales-Solutions/automationframeworkexecution.git",
  },
];

export default function App() {
  const [showDocsModal, setShowDocsModal] = useState(false);

  // Download Documents from the Document Function
  const handleDocumentDownload = async (doc) => {
    try {
      const fileUrl = `${window.location.origin}${doc.url}`;
      const response = await fetch(fileUrl, { cache: "no-store" });

      if (!response.ok) {
        setStatus(`Document not found: ${doc.name} (${response.status})`);
        return;
      }

      const contentType = response.headers.get("content-type") || "";

      // Block HTML fallback pages
      if (contentType.includes("text/html")) {
        setStatus(`Document path is wrong or file is missing: ${doc.name}`);
        return;
      }

      const blob = await response.blob();

      if (!blob || blob.size === 0) {
        setStatus(`Document is empty or unavailable: ${doc.name}`);
        return;
      }

      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = doc.url.split("/").pop() || doc.name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);

      setStatus(`Document downloaded: ${doc.name}`);
    } catch (error) {
      setStatus(`Unable to download document: ${doc.name}`);
    }
  };

  return (
    <div className="pageWithActions">
      <div className="topActionsBar">
        <button className="documentsBtn" onClick={() => setShowDocsModal(true)}>
          Documents
        </button>
      </div>
      <div className="card">
        <h1 className="pluginsTitle"> Plugins </h1>
        <p className="subtitle">
          Click the Extensions links to open the corresponding Git repository.
        </p>
        {/* <p className="subtitle">
        From there, you can add or install the required extensions as needed.
        </p> */}

        <div className="extensionsList">
          {PLUGIN_EXTENSIONS.map((extension, index) => (
            <div className="extensionRow" key={index}>
              <span className="extensionName">{extension.name}</span>
              <div className="repoAction">
                <a
                  href={extension.gitUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="extensionLink"
                >
                  Open GIT Repository
                </a>
                <div className="repoUrl">{extension.gitUrl}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {showDocsModal && (
        <div className="modalOverlay" onClick={() => setShowDocsModal(false)}>
          <div className="modalCard" onClick={(e) => e.stopPropagation()}>
            <div className="modalHeader">
              <h2>Extension Documents</h2>
              <button
                className="closeModalBtn"
                onClick={() => setShowDocsModal(false)}
              >
                ✕
              </button>
            </div>

            <div className="documentsList">
              {PLUGIN_DOCUMENTS.map((doc, index) => (
                <div className="documentRow" key={index}>
                  <span>{doc.name}</span>
                  <button
                    type="button"
                    className="downloadDocBtn"
                    // disabled={!doc.available}
                    onClick={() => handleDocumentDownload(doc)}
                  >
                    Download
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
