import React, { useMemo, useRef, useState, useEffect } from "react";

import "../styles/rtmgenerator.css";

/* ======================================================
   FILE CONFIGURATION
====================================================== */

const ALLOWED_EXTENSIONS = ["csv", "xlsx", "xls", "json", "txt"];

const MAX_FILE_SIZE_MB = 25;

const RTM_DOCUMENTS = [
  {
    name: "TestCase Template",
    url: "/docs/TestCases_Suite1.csv",
    // available: false,
  },
  {
    name: "UserStories Template",
    url: "/docs/UserStories_ProjectA.csv",
    // available: true,
  },
];

/* ======================================================
   COMPONENT
====================================================== */
export default function RTMGenerator() {
  const storyInputRef = useRef(null);
  const testcaseInputRef = useRef(null);

  /* ======================================================
     STATES
  ====================================================== */
  const [showDocsModal, setShowDocsModal] = useState(false);
  const [userStoryFiles, setUserStoryFiles] = useState([]);

  const [testCaseFiles, setTestCaseFiles] = useState([]);

  const [showStories, setShowStories] = useState(false);

  const [showTestCases, setShowTestCases] = useState(false);

  const [busy, setBusy] = useState(false);

  const [status, setStatus] = useState("");

  const [progressMessage, setProgressMessage] = useState("");

  const [previewData, setPreviewData] = useState(null);

  const [reportUrl, setReportUrl] = useState("");

  const [retryPayload, setRetryPayload] = useState(null);

  /* ======================================================
     VALIDATION
  ====================================================== */

  const validateBeforeSend = () => {
    if (userStoryFiles.length === 0) {
      setStatus("Please upload user story files.");

      return false;
    }

    if (testCaseFiles.length === 0) {
      setStatus("Please upload test case files.");

      return false;
    }

    return true;
  };

  /* ======================================================
     FILE VALIDATION
  ====================================================== */

  const validateFile = (file) => {
    const extension = file.name.split(".").pop()?.toLowerCase();

    if (!ALLOWED_EXTENSIONS.includes(extension)) {
      return `${file.name} unsupported`;
    }

    const size = file.size / (1024 * 1024);

    if (size > MAX_FILE_SIZE_MB) {
      return `${file.name} exceeds 25MB`;
    }

    return null;
  };

  /* ======================================================
     FILE ADD HANDLER
  ====================================================== */

  const addFiles = (incomingFiles, type) => {
    if (!incomingFiles) return;

    const files = Array.from(incomingFiles);

    const validFiles = [];

    let skipped = 0;

    files.forEach((file) => {
      const error = validateFile(file);

      if (error) {
        skipped++;

        return;
      }

      validFiles.push(file);
    });

    if (type === "stories") {
      setUserStoryFiles((prev) => [...prev, ...validFiles]);
    }

    if (type === "testcases") {
      setTestCaseFiles((prev) => [...prev, ...validFiles]);
    }

    // if (validFiles.length > 0) {
    //   setStatus(`${validFiles.length} file(s) added`);
    // }

    // if (skipped > 0) {
    //   setStatus(`${skipped} file(s) skipped`);
    // }
  };
  /* ======================================================
     FILE INPUT HANDLERS
  ====================================================== */

  const handleStoryUpload = (event) => {
    addFiles(event.target.files, "stories");

    event.target.value = "";
  };

  const handleTestCaseUpload = (event) => {
    addFiles(event.target.files, "testcases");

    event.target.value = "";
  };

  /* ======================================================
     DRAG DROP HANDLERS
  ====================================================== */

  const handleDrag = (event) => {
    event.preventDefault();

    event.stopPropagation();
  };

  const handleStoryDrop = (event) => {
    event.preventDefault();

    event.stopPropagation();

    addFiles(event.dataTransfer.files, "stories");
  };

  const handleTestCaseDrop = (event) => {
    event.preventDefault();

    event.stopPropagation();

    addFiles(event.dataTransfer.files, "testcases");
  };

  /* ======================================================
     REMOVE FILES
  ====================================================== */

  const removeStoryFile = (fileName) => {
    setUserStoryFiles((prev) => {
      const updatedFiles = prev.filter((file) => file.name !== fileName);

      setStatus(
        `Removed "${fileName}". ${updatedFiles.length} user story file(s) remaining.`,
      );

      return updatedFiles;
    });
  };

  const removeTestCaseFile = (fileName) => {
    setTestCaseFiles((prev) => {
      const updatedFiles = prev.filter((file) => file.name !== fileName);

      setStatus(
        `Removed "${fileName}". ${updatedFiles.length} test case file(s) remaining.`,
      );

      return updatedFiles;
    });
  };

  useEffect(() => {
    if (userStoryFiles.length === 0 && testCaseFiles.length === 0) {
      return;
    }

    setStatus(
      `Uploaded ${userStoryFiles.length} User Story file(s) and ${testCaseFiles.length} Test Case file(s).`,
    );
  }, [userStoryFiles, testCaseFiles]);
  /* ======================================================
     CREATE FORM DATA
  ====================================================== */

  const prepareFormData = () => {
    const formData = new FormData();

    userStoryFiles.forEach((file) => {
      formData.append("stories", file);
    });

    testCaseFiles.forEach((file) => {
      formData.append("testcases", file);
    });

    return formData;
  };

  /* ======================================================
     PREVIEW RTM
  ====================================================== */

  const previewRTM = async () => {
    setStatus("");

    if (!validateBeforeSend()) {
      return;
    }

    try {
      setBusy(true);

      setProgressMessage("Generating RTM Preview...");

      const formData = prepareFormData();

      const response = await fetch("http://192.168.3.173:8080/api/rtm/preview", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        const error = await response.text();

        throw new Error(error || "Preview generation failed");
      }

      const data = await response.json();

      setPreviewData(data);

      setStatus("Preview generated successfully.");
    } catch (error) {
      setStatus(error.message || "Preview failed");
    } finally {
      setBusy(false);

      setProgressMessage("");
    }
  };

  //PREVIEW AFTER GENERATE

  const loadPreview = async () => {
    const formData = prepareFormData();

    const response = await fetch("http://192.168.3.173:8080/api/rtm/preview", {
      method: "POST",
      body: formData,
    });

    if (!response.ok) {
      throw new Error("Preview generation failed");
    }

    const data = await response.json();

    setPreviewData(data);
  };

  /* ======================================================
     GENERATE EXCEL
  ====================================================== */

  const generateRTM = async (existingPayload = null) => {
    setStatus("");

    if (!existingPayload && !validateBeforeSend()) {
      return;
    }

    try {
      setBusy(true);

      setProgressMessage("Generating RTM Excel...");

      setReportUrl("");

      const formData = existingPayload || prepareFormData();

      setRetryPayload(formData);

      const response = await fetch("http://192.168.3.173:8080/api/rtm/generate", {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        const error = await response.text();

        throw new Error(error || "RTM generation failed");
      }

      const blob = await response.blob();

      const url = window.URL.createObjectURL(blob);

      const download = document.createElement("a");

      download.href = url;

      download.download = "RTM Matrix.xlsx";

      document.body.appendChild(download);

      download.click();

      document.body.removeChild(download);

      setReportUrl(url);

      setStatus("RTM generated successfully.");
    } catch (error) {
      setStatus(error.message || "RTM generation failed");
    } finally {
      setBusy(false);

      setProgressMessage("");
    }
  };

  /* ======================================================
     BUTTON ENABLE
  ====================================================== */

  const canGenerate = useMemo(() => {
    return userStoryFiles.length > 0 && testCaseFiles.length > 0 && !busy;
  }, [userStoryFiles, testCaseFiles, busy]);

  /* ======================================================
     Document Button
  ====================================================== */
  const handleDocumentDownload = async (doc) => {
    try {
      const fileUrl = `${window.location.origin}${doc.url}`;
      const response = await fetch(fileUrl, { cache: "no-store" });

      if (!response.ok) {
        setStatus(`Document not found: ${doc.name} (${response.status})`);
        return;
      }

      const contentType = response.headers.get("content-type") || "";

      // Block HTML fallback pages
      if (contentType.includes("text/html")) {
        setStatus(`Document path is wrong or file is missing: ${doc.name}`);
        return;
      }

      const blob = await response.blob();

      if (!blob || blob.size === 0) {
        setStatus(`Document is empty or unavailable: ${doc.name}`);
        return;
      }

      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = doc.url.split("/").pop() || doc.name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);

      setStatus(`Document downloaded: ${doc.name}`);
    } catch (error) {
      setStatus(`Unable to download document: ${doc.name}`);
    }
  };

  /* ======================================================
     UI
  ====================================================== */
  return (
    <div className="pageWithActionstestcase">
      <div className="topActionsBar">
        <button className="documentsBtn" onClick={() => setShowDocsModal(true)}>
          Documents
        </button>
      </div>
      <div className="cardrtm">
        <h1>RTM Generator</h1>

        <p className="subtitle">
          Upload User Stories → Upload Test Cases → Preview → Generate Excel
        </p>
        {/* USER STORIES */}

        <div className="section">
          <label>
            User Story Files
            <span className="required">*</span>
          </label>

          <div
            className="dropzone"
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleStoryDrop}
            onClick={() => !busy && storyInputRef.current?.click()}
            style={{
              cursor: busy ? "not-allowed" : "pointer",
            }}
          >
            <p>Drag & Drop User Story CSV files or Click to Browse</p>

            <input
              ref={storyInputRef}
              type="file"
              multiple
              disabled={busy}
              accept=".csv"
              style={{
                display: "none",
              }}
              onChange={handleStoryUpload}
            />
          </div>
        </div>

        {/* TEST CASES */}

        <div className="section">
          <label>
            Test Case Files
            <span className="required">*</span>
          </label>

          <div
            className="dropzone"
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleTestCaseDrop}
            onClick={() => !busy && testcaseInputRef.current?.click()}
            style={{
              cursor: busy ? "not-allowed" : "pointer",
            }}
          >
            <p>Drag & Drop Test Case CSV files or Click to Browse</p>

            <input
              ref={testcaseInputRef}
              type="file"
              multiple
              disabled={busy}
              accept=".csv"
              style={{
                display: "none",
              }}
              onChange={handleTestCaseUpload}
            />
          </div>
        </div>

        {/* USER STORY FILE LIST */}

        <div className="section">
          <button
            className="viewFilesBtn"
            disabled={userStoryFiles.length === 0}
            onClick={() => setShowStories((prev) => !prev)}
          >
            {showStories
              ? "Hide User Story Files"
              : `View User Story Files (${userStoryFiles.length})`}
          </button>

          {showStories && (
            <div className="fileListView">
              {userStoryFiles.map((file, index) => (
                <div key={index} className="fileRow">
                  <span className="fileName">{file.name}</span>

                  <button
                    className="removeIconBtn"
                    onClick={() => removeStoryFile(file.name)}
                  >
                    ✕
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* TEST CASE FILE LIST */}

        <div className="section">
          <button
            className="viewFilesBtn"
            disabled={testCaseFiles.length === 0}
            onClick={() => setShowTestCases((prev) => !prev)}
          >
            {showTestCases
              ? "Hide Test Case Files"
              : `View Test Case Files (${testCaseFiles.length})`}
          </button>

          {showTestCases && (
            <div className="fileListView">
              {testCaseFiles.map((file, index) => (
                <div key={index} className="fileRow">
                  <span className="fileName">{file.name}</span>

                  <button
                    className="removeIconBtn"
                    onClick={() => removeTestCaseFile(file.name)}
                  >
                    ✕
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* BUTTONS */}

        <div className="buttonRow">
          <button
            className="runBtn"
            disabled={!canGenerate}
            onClick={() => generateRTM()}
          >
            {busy ? "Generating..." : "Generate Excel"}
          </button>
          <button
            className="previewBtn"
            disabled={!canGenerate}
            onClick={previewRTM}
          >
            Preview RTM
          </button>

          {retryPayload && (
            <button
              className="retryBtn"
              disabled={busy}
              onClick={() => generateRTM(retryPayload)}
            >
              Retry
            </button>
          )}
        </div>

        {/* STATUS */}

        {status && <div className="status">{status}</div>}

        {/* PREVIEW SUMMARY */}

        {previewData && (
          <div className="executionPanel">
            <div className="executionHeader">
              <strong>RTM Preview Summary</strong>
            </div>

            <div className="summaryBox">
              <p>✔ Stories : {previewData.storyCount ?? "-"}</p>

              <p>✔ Test Cases : {previewData.testCaseCount ?? "-"}</p>

              <p>✔ Mapping Mode : {previewData.mappingMode ?? "-"}</p>

              <p>✔ Match Threshold : {previewData.matchThreshold ?? "-"}</p>

              <p>
                ✔ Matched By Keyword : {previewData.matchedByKeyword ?? "-"}
              </p>

              <p>✔ Matched By Link : {previewData.matchedByLink ?? "-"}</p>

              <p>
                ✔ Unmatched Test Cases : {previewData.unmatchedTestCases ?? "-"}
              </p>
            </div>

            {/* PREVIEW TABLE */}

            <div className="previewContainer">
              <h3>Traceability Preview</h3>

              <div className="tableWrapper">
                <table className="previewTable">
                  <thead>
                    <tr>
                      <th>Story ID</th>

                      <th>Story Title</th>

                      <th>Test ID</th>

                      <th>Test Title</th>

                      <th>Source</th>

                      <th>Score</th>

                      <th>Evidence</th>
                    </tr>
                  </thead>

                  <tbody>
                    {Array.isArray(previewData.matches) &&
                      previewData.matches.map((item, index) => (
                        <tr key={index}>
                          <td>{item.storyId}</td>

                          <td>{item.storyTitle}</td>

                          <td>{item.testId}</td>

                          <td>{item.testTitle}</td>

                          <td>{item.source}</td>

                          <td>{item.score}</td>

                          <td>{item.evidence}</td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* DOWNLOAD */}

        {reportUrl && (
          <div className="section">
            <a href={reportUrl} download="RTM.xlsx" className="downloadBtn">
              Download Generated RTM Excel
            </a>
          </div>
        )}
      </div>

      {showDocsModal && (
        <div className="modalOverlay" onClick={() => setShowDocsModal(false)}>
          <div className="modalCard" onClick={(e) => e.stopPropagation()}>
            <div className="modalHeader">
              <h2>Extension Documents</h2>
              <button
                className="closeModalBtn"
                onClick={() => setShowDocsModal(false)}
              >
                ✕
              </button>
            </div>

            <div className="documentsList">
              {RTM_DOCUMENTS.map((doc, index) => (
                <div className="documentRow" key={index}>
                  <span>{doc.name}</span>
                  <button
                    type="button"
                    className="downloadDocBtn"
                    // disabled={!doc.available}
                    onClick={() => handleDocumentDownload(doc)}
                  >
                    Download
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
