package com.sodales.rtm.model;

import java.util.List;
import java.util.Map;
import java.util.Set;

/** Everything needed to build the single RTM workbook. */
public record RtmDataset(
        int storyFileCount,
        int testFileCount,
        int storyCount,
        int testCaseCount,
        String mappingMode,
        int matchThreshold,
        int matchedByLink,
        int matchedByKeyword,
        int unmatchedTestCases,
        List<Story> stories,
        List<TestCaseInfo> testCases,
        Map<String, Set<String>> storyToTests,
        List<Match> matches
) { }
