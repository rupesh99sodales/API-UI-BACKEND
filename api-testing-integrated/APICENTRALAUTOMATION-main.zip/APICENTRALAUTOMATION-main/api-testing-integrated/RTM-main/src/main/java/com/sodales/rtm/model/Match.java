package com.sodales.rtm.model;

/**
 * An association between a test case and a user story.
 * source = "Link" (authoritative, from an explicit mapping column) or
 *          "Keyword" (suggested, from keyword overlap). For Link matches the
 * score is not meaningful (0); evidence explains how the link was derived.
 */
public record Match(
        String testId,
        String testTitle,
        String storyId,
        String storyTitle,
        String source,
        int score,
        String evidence
) { }
