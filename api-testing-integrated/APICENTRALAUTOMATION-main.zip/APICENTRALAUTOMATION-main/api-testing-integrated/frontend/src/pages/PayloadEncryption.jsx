import React, { useState } from "react";
import CryptoJS from "crypto-js";
import "../styles/payloadencryption.css";

export default function App() {
  const [encryptText, setEncryptText] = useState("");
  const [encryptKey, setEncryptKey] = useState("");
  const [encryptedResult, setEncryptedResult] = useState("");

  const [decryptText, setDecryptText] = useState("");
  const [decryptKey, setDecryptKey] = useState("");
  const [decryptedResult, setDecryptedResult] = useState("");

  const [status, setStatus] = useState("");

  const onClickEncode = () => {
    if (!encryptText || !encryptKey) {
      setEncryptedResult("Please enter text and key.");
      return;
    }

    const encrypted = CryptoJS.AES.encrypt(encryptText, encryptKey).toString();

    setEncryptedResult(encrypted);
    setStatus("Payload encrypted successfully.");
  };

  const onClickDecode = () => {
    if (!decryptText || !decryptKey) {
      setDecryptedResult("Please enter encrypted text and key.");
      return;
    }

    try {
      const decrypted = CryptoJS.AES.decrypt(decryptText, decryptKey).toString(
        CryptoJS.enc.Utf8,
      );

      if (decrypted) {
        setDecryptedResult(decrypted);
        setStatus("Payload decrypted successfully.");
      } else {
        setDecryptedResult("Please enter a valid key.");
      }
    } catch (error) {
      setDecryptedResult("Please enter a valid key.");
    }
  };

  const onClickReset1 = () => {
    setEncryptText("");
    setEncryptKey("");
    setEncryptedResult("");
  };

  const onClickReset2 = () => {
    setDecryptText("");
    setDecryptKey("");
    setDecryptedResult("");
  };

  const copyText = async (text) => {
    try {
      await navigator.clipboard.writeText(text);
      setStatus("Copied to clipboard.");
    } catch {
      setStatus("Unable to copy text.");
    }
  };

  return (
    <div className="pageWithActionsPayloadEncrypt">
      <div className="cardpayload">
        <h1 className="pluginsTitle">Payload Encryption / Decryption</h1>

        <p className="subtitle">
          Encrypt and decrypt payloads using AES encryption.
        </p>

        <div className="container">
          {/* Encryption */}
          <div className="box">
            <h2>Payload Encryption</h2>

            <textarea
              placeholder="Enter decrypted text here..."
              value={encryptText}
              onChange={(e) => setEncryptText(e.target.value)}
            />

            <input
              type="text"
              placeholder="Enter your key..."
              value={encryptKey}
              onChange={(e) => setEncryptKey(e.target.value)}
            />

            <textarea
              readOnly
              placeholder="Encrypted payload"
              value={encryptedResult}
            />

            <div className="buttonGroup">
              <button className="encodeDecode" onClick={onClickEncode}>
                Encode
              </button>

              <button className="reset" onClick={onClickReset1}>
                Reset
              </button>

              <button
                className="copy1"
                onClick={() => copyText(encryptedResult)}
              >
                Copy
              </button>
            </div>
          </div>

          {/* Decryption */}
          <div className="box">
            <h2>Payload Decryption</h2>

            <textarea
              placeholder="Enter encrypted text here..."
              value={decryptText}
              onChange={(e) => setDecryptText(e.target.value)}
            />

            <input
              type="text"
              placeholder="Enter your key..."
              value={decryptKey}
              onChange={(e) => setDecryptKey(e.target.value)}
            />

            <textarea
              readOnly
              placeholder="Decrypted payload"
              value={decryptedResult}
            />

            <div className="buttonGroup">
              <button className="encodeDecode" onClick={onClickDecode}>
                Decode
              </button>

              <button className="reset" onClick={onClickReset2}>
                Reset
              </button>

              <button
                className="copy2"
                onClick={() => copyText(decryptedResult)}
              >
                Copy
              </button>
            </div>
          </div>
        </div>

        {status && <div className="status">{status}</div>}
        <div className="info-box">
          <>
            <strong>Note:</strong>
            <ul>
              <li>
                {" "}
                Encryption / Decryption Key is provided from Config Team.{" "}
              </li>
              <li>
                For encryption/decryption, only pass the inner payload value. Do
                not send the complete JSON object or the key name.
              </li>
              <li>
                <strong>Example:</strong>
                <ul>
                  <li>
                    <strong>Payload received:</strong>
                    <code>
                      &#123;&quot;D4OXYPALUYAIDNSO&quot;:&quot;UserTransactionData123&quot;&#125;
                    </code>
                  </li>
                  <li>
                    <strong>Value to be sent for encryption/decryption:</strong>
                    <code>UserTransactionData123</code>
                  </li>
                </ul>
              </li>
            </ul>
          </>
        </div>
      </div>
    </div>
  );
}
