package com.sodales.rtm.web;

import com.sodales.rtm.model.RtmDataset;
import com.sodales.rtm.service.ExcelWriter;
import com.sodales.rtm.service.TraceabilityService;
import com.sodales.rtm.service.TraceabilityService.Columns;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/rtm")
public class TraceabilityController {

    private static final String XLSX_MIME =
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";

    private final TraceabilityService service;
    private final ExcelWriter excel;

    public TraceabilityController(TraceabilityService service, ExcelWriter excel) {
        this.service = service;
        this.excel = excel;
    }

    /**
     * Upload one-or-more user-story CSVs and one-or-more test-case CSVs (repeat
     * the key to attach several) and download ONE traceability Excel. Test cases
     * are mapped to user stories by keyword overlap of title + description + tags.
     * minScore tunes how strong a match must be (default 2; a shared tag = 2).
     */
    @PostMapping(path = "/generate", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<byte[]> generate(
            @RequestParam("stories") List<MultipartFile> stories,
            @RequestParam("testcases") List<MultipartFile> testcases,
            @RequestParam(required = false, defaultValue = "0") int minScore,
            @RequestParam(required = false) String storyIdColumn,
            @RequestParam(required = false) String storyTitleColumn,
            @RequestParam(required = false) String storyStateColumn,
            @RequestParam(required = false) String storyAcColumn,
            @RequestParam(required = false) String storyDescColumn,
            @RequestParam(required = false) String storyTagColumn,
            @RequestParam(required = false) String testIdColumn,
            @RequestParam(required = false) String testTitleColumn,
            @RequestParam(required = false) String testTagColumn,
            @RequestParam(required = false) String testDescColumn,
            @RequestParam(required = false) String testLinkColumn) throws IOException {

        Columns cols = new Columns(storyIdColumn, storyTitleColumn, storyStateColumn,
                storyAcColumn, storyDescColumn, storyTagColumn,
                testIdColumn, testTitleColumn, testDescColumn, testTagColumn, testLinkColumn);
        RtmDataset data = service.generate(stories, testcases, cols, minScore);
        byte[] body = excel.toXlsx(data);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=traceability.xlsx")
                .contentType(MediaType.parseMediaType(XLSX_MIME))
                .body(body);
    }

    /** Same processing, returned as JSON (counts, matches with evidence) — no download. */
    @PostMapping(path = "/preview", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public RtmDataset preview(
            @RequestParam("stories") List<MultipartFile> stories,
            @RequestParam("testcases") List<MultipartFile> testcases,
            @RequestParam(required = false, defaultValue = "0") int minScore,
            @RequestParam(required = false) String storyIdColumn,
            @RequestParam(required = false) String storyTitleColumn,
            @RequestParam(required = false) String storyStateColumn,
            @RequestParam(required = false) String storyAcColumn,
            @RequestParam(required = false) String storyDescColumn,
            @RequestParam(required = false) String storyTagColumn,
            @RequestParam(required = false) String testIdColumn,
            @RequestParam(required = false) String testTitleColumn,
            @RequestParam(required = false) String testTagColumn,
            @RequestParam(required = false) String testDescColumn,
            @RequestParam(required = false) String testLinkColumn) throws IOException {

        Columns cols = new Columns(storyIdColumn, storyTitleColumn, storyStateColumn,
                storyAcColumn, storyDescColumn, storyTagColumn,
                testIdColumn, testTitleColumn, testDescColumn, testTagColumn, testLinkColumn);
        return service.generate(stories, testcases, cols, minScore);
    }
}
