package org.sodales;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/** Thread-safe, run-scoped log storage. */
public final class LogCollector {
    private static final Map<String, CopyOnWriteArrayList<String>> RUN_LOGS = new ConcurrentHashMap<>();
    private static final ThreadLocal<String> CURRENT_RUN = new ThreadLocal<>();

    private LogCollector() {
    }

    public static void createRun(String runId) {
        RUN_LOGS.putIfAbsent(runId, new CopyOnWriteArrayList<>());
    }

    public static void beginRun(String runId) {
        createRun(runId);
        CURRENT_RUN.set(runId);
    }

    public static void endRun() {
        CURRENT_RUN.remove();
    }

    public static void log(String message) {
        String runId = CURRENT_RUN.get();
        if (runId == null) {
            System.out.println("[unscoped] " + Instant.now() + " " + safe(message));
            return;
        }
        log(runId, message);
    }

    public static void log(String runId, String message) {
        String line = Instant.now() + " " + safe(message);
        System.out.println("[" + runId + "] " + line);
        CopyOnWriteArrayList<String> lines = RUN_LOGS.computeIfAbsent(runId, k -> new CopyOnWriteArrayList<>());
        lines.add(line);
        if (lines.size() > 3000)
            lines.subList(0, Math.min(1000, lines.size())).clear();
    }

    public static List<String> getLogs(String runId) {
        List<String> lines = RUN_LOGS.get(runId);
        return lines == null ? List.of() : new ArrayList<>(lines);
    }

    public static List<String> getLogs() {
        String runId = CURRENT_RUN.get();
        return runId == null ? List.of() : getLogs(runId);
    }

    public static void clear() {
        String runId = CURRENT_RUN.get();
        if (runId != null)
            RUN_LOGS.put(runId, new CopyOnWriteArrayList<>());
    }

    public static void removeRun(String runId) {
        RUN_LOGS.remove(runId);
    }

    private static String safe(String message) {
        return message == null ? "" : message;
    }
}
