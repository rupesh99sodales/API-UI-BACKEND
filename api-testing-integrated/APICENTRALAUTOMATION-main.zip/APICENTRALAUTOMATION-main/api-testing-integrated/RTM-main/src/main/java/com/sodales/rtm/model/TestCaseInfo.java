package com.sodales.rtm.model;

/** A test case, merged and de-duplicated across all uploaded test-case files. */
public record TestCaseInfo(String id, String title, String state, String tags, String description) { }
