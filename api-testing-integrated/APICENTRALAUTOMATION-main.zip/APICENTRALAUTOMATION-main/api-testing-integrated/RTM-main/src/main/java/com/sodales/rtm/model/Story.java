package com.sodales.rtm.model;

/** A user story, merged and de-duplicated across all uploaded story files. */
public record Story(String id, String title, String description,
                    String acceptanceCriteria, String state, String tags) { }
