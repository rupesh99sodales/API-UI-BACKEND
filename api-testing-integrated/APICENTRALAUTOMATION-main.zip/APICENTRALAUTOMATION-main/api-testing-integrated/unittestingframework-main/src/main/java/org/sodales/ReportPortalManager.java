package org.sodales;

import java.net.http.HttpClient;
import java.net.URI;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Instant;
import java.util.UUID;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
public class ReportPortalManager {

	public static void startLaunch() {

	    try {

	    	/*String requestBody =
	    	        "{"
	    	        + "\"name\":\"" + LAUNCH_NAME + "\","
	    	        + "\"description\":\"QUALITY API Automation Run\","
	    	        + "\"mode\":\"DEFAULT\","
	    	        + "\"startTime\":\"" + Instant.now().toString() + "\""
	    	        + "}";
                    */
	    	ObjectNode launch = mapper.createObjectNode();

	    	launch.put("name", LAUNCH_NAME);
	    	launch.put("description", "QUALITY API Automation Run");
	    	launch.put("mode", "DEFAULT");
	    	launch.put("startTime", Instant.now().toString());

    	
	    	String requestBody = mapper.writeValueAsString(launch);

	        HttpRequest request = HttpRequest.newBuilder().uri(URI.create(ENDPOINT + 
	        		            "/api/v1/" +
	                            PROJECT +
	                            "/launch"
	                            )
	                        )
	                        .header(
	                            "Authorization",
	                            "Bearer " + API_KEY
	                        )
	                        .header(
	                            "Content-Type",
	                            "application/json"
	                        )
	                        .POST(
	                            HttpRequest.BodyPublishers.ofString(requestBody)
	                        )
	                        .build();


	        HttpResponse<String> response =
	                client.send(
	                    request,
	                    HttpResponse.BodyHandlers.ofString());


	        System.out.println(
	        	    "ReportPortal Status Code : "
	        	    + response.statusCode());

	        	System.out.println(
	        	    "ReportPortal Response Body : "
	        	    + response.body());
	        	
	        	String responseBody = response.body();

	                //launchId =
	        	    //      responseBody
	        	    //    .split("\"id\":\"")[1]
	        	      //  .split("\"")[0];
	        	JsonNode json = mapper.readTree(responseBody);

	        	launchId = json.get("id").asText();

	        	System.out.println(
	        	        "Launch ID : "
	        	        + launchId);

	    }
	    catch(Exception e){

	        e.printStackTrace();
	    }

	}
	
	
	public static void startTestItem(String testName) {

	    try {

	        ObjectNode item = mapper.createObjectNode();

	        item.put("name", testName);
	        item.put("description", "API Test");
	        item.put("startTime", Instant.now().toString());
	        item.put("type", "STEP");
            item.put("launchUuid", launchId);

	        String requestBody = mapper.writeValueAsString(item);
           
	        System.out.println("Test Item Request Body:");
	        System.out.println(requestBody);
	        HttpRequest request =
	                HttpRequest.newBuilder()
	                        .uri(
	                                URI.create(
	                                        ENDPOINT +
	                                        "/api/v1/" +
	                                        PROJECT +
	                                        "/item"
	                                )
	                        )
	                        .header("Authorization", "Bearer " + API_KEY)
	                        .header("Content-Type", "application/json")
	                        .POST(HttpRequest.BodyPublishers.ofString(requestBody))
	                        .build();

	        HttpResponse<String> response =
	                client.send(request, HttpResponse.BodyHandlers.ofString());

	        System.out.println("Test Item Status : " + response.statusCode());
	        System.out.println("Test Item Response : " + response.body());

	        JsonNode json = mapper.readTree(response.body());

	        if (response.statusCode() == 201 && json.has("id")) {

	            testItemId = json.get("id").asText();

	            System.out.println("Test Item ID : " + testItemId);

	        } else {

	            System.out.println("Failed to create Test Item.");

	        }

	    }
	    catch (Exception e) {

	        e.printStackTrace();

	    }

	}
	
	public static void log(String message) {

	    try {

	        ObjectNode log = mapper.createObjectNode();

	        log.put("itemUuid", testItemId);
	        log.put("launchUuid", launchId);
	        log.put("level", "INFO");
	        log.put("time", Instant.now().toString());
	        log.put("message", message);

	        String requestBody = mapper.writeValueAsString(log);

	        HttpRequest request =
	                HttpRequest.newBuilder()
	                        .uri(
	                                URI.create(
	                                        ENDPOINT +
	                                        "/api/v1/" +
	                                        PROJECT +
	                                        "/log"
	                                )
	                        )
	                        .header("Authorization", "Bearer " + API_KEY)
	                        .header("Content-Type", "application/json")
	                        .POST(HttpRequest.BodyPublishers.ofString(requestBody))
	                        .build();

	        HttpResponse<String> response =
	                client.send(
	                        request,
	                        HttpResponse.BodyHandlers.ofString()
	                );

	        System.out.println("Log Status : " + response.statusCode());

	    } catch (Exception e) {

	        e.printStackTrace();

	    }

	}
	
	public static void finishTestItem(String status) {

	    try {

	        ObjectNode finish = mapper.createObjectNode();

	        finish.put(
	                "endTime",
	                Instant.now().toString()
	        );

	        finish.put(
	                "status",
	                status
	        );


	        String requestBody =
	                mapper.writeValueAsString(finish);


	        HttpRequest request =
	                HttpRequest.newBuilder()
	                        .uri(
	                            URI.create(
	                                ENDPOINT +
	                                "/api/v1/" +
	                                PROJECT +
	                                "/item/" +
	                                testItemId
	                            )
	                        )
	                        .header(
	                            "Authorization",
	                            "Bearer " + API_KEY
	                        )
	                        .header(
	                            "Content-Type",
	                            "application/json"
	                        )
	                        .PUT(
	                            HttpRequest.BodyPublishers.ofString(requestBody)
	                        )
	                        .build();

	        HttpResponse<String> response =
	                client.send(
	                    request,
	                    HttpResponse.BodyHandlers.ofString());

	        System.out.println(
	            "Finish Test Item Status : "
	            + response.statusCode());


	        System.out.println(
	            "Finish Test Item Response : "
	            + response.body());


	    }
	    catch(Exception e){

	        e.printStackTrace();

	    }

	}
	
	//finish launch method 
	public static void finishLaunch() {

	    try {

	        ObjectNode finish = mapper.createObjectNode();

	        finish.put(
	                "endTime",
	                Instant.now().toString()
	        );


	        String requestBody =
	                mapper.writeValueAsString(finish);


	        HttpRequest request =
	                HttpRequest.newBuilder()
	                        .uri(
	                            URI.create(
	                                ENDPOINT +
	                                "/api/v1/" +
	                                PROJECT +
	                                "/launch/" +
	                                launchId +
	                                "/finish"
	                            )
	                        )
	                        .header(
	                            "Authorization",
	                            "Bearer " + API_KEY
	                        )
	                        .header(
	                            "Content-Type",
	                            "application/json"
	                        )
	                        .PUT(
	                            HttpRequest.BodyPublishers.ofString(requestBody)
	                        )
	                        .build();


	        HttpResponse<String> response =
	                client.send(
	                        request,
	                        HttpResponse.BodyHandlers.ofString());


	        System.out.println(
	                "Finish Launch Status : "
	                + response.statusCode());


	        System.out.println(
	                "Finish Launch Response : "
	                + response.body());


	    }
	    catch(Exception e){

	        e.printStackTrace();

	    }

	}
    // HTTP Client
    private static final HttpClient client = HttpClient.newHttpClient();

    private static final ObjectMapper mapper = new ObjectMapper();
    
    // Launch ID received from ReportPortal
    private static String launchId;
  
    private static String testItemId;

    private static final String REPORTPORTAL_CONFIG =
            "src/main/resources/reportportal.properties";


    // Read values from reportportal.properties
    private static final String ENDPOINT =
            PropertyLoader.loadProperties(
                    REPORTPORTAL_CONFIG,
                    "rp.endpoint");


    private static final String API_KEY =
            PropertyLoader.loadProperties(
                    REPORTPORTAL_CONFIG,
                    "rp.api.key");


    private static final String PROJECT =
            PropertyLoader.loadProperties(
                    REPORTPORTAL_CONFIG,
                    "rp.project");


    private static final String LAUNCH_NAME =
            PropertyLoader.loadProperties(
                    REPORTPORTAL_CONFIG,
                    "rp.launch");

    public static void testConfiguration(){

        System.out.println("ReportPortal Endpoint : " + ENDPOINT);
        System.out.println("Project : " + PROJECT);
        System.out.println("Launch Name : " + LAUNCH_NAME);
              
    }
    
    public static String getLaunchId(){

        return launchId;
              }
    
    public static String getTestItemId() {
        return testItemId;
    }
    
}