import React, { useMemo, useRef, useState, useEffect } from "react";
import Select from "react-select";
import "../styles/global.css";

const REQUIRED_COLUMNS = [
  "TestName",
  "Method",
  "URL",
  "Headers",
  "BodyType",
  "Payload",
  "FormData",
  "FilePath",
  "ExpectedStatus",
  "ExpectedResponseContains",
  "Skip?",
  "GlobalVariableJsonorXMLPath",
  "GlobalVariable",
  "JsonorXML",
];

const API_TESTING_DOCUMENTS = [
  {
    name: "API Testing Excel Template",
    url: "/docs/Dummy File For API Testing.xlsx",
  },
  {
    name: "API TEST PDF",
    url: "/docs/",
  },
  {
    name: "API Testing Process Document",
    url: "/docs/api-testing-process.docx",
  },
];

export default function App() {
  const [authType, setAuthType] = useState("BASIC");
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState(false);
  const [reportUrl, setReportUrl] = useState("");
  const [showClientSecret, setShowClientSecret] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [logs, setLogs] = useState([]);
  const [showDocsModal, setShowDocsModal] = useState(false);
  const [runId, setRunId] = useState(null);

  const [projects, setProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState(null);

  const [newProject, setNewProject] = useState("");
  const [showAddProjectModal, setShowAddProjectModal] = useState(false);
  const [reportPortalEnabled, setReportPortalEnabled] = useState(false);// ReportPortal checkbox state

  const fileInputRef = useRef(null);
  const [form, setForm] = useState({
    username: "",
    password: "",
    clientId: "",
    clientSecret: "",
    tokenUrl: "",
    grantType: "client_credentials",
  });

  const canRun = useMemo(() => {
    return !!file && !busy;
  }, [file, busy]);

  // FILE SELECTION  
  const handleSelectedFile = (selected) => {
    setStatus("");
    setReportUrl("");

    if (!selected) {
      setFile(null);
      return;
    }

    const lower = selected.name.toLowerCase();

    if (!(lower.endsWith(".xlsx") || lower.endsWith(".xls"))) {
      setStatus("Only .xlsx or .xls files are allowed.");
      setFile(null);
      return;
    }

    setFile(selected);
    setStatus(`Selected file: ${selected.name}`);
  };

  const onFileChange = (event) => {
    const selected = event.target.files?.[0];
    handleSelectedFile(selected);
  };

  
  // DRAG & DROP
  
  const handleDrag = (event) => {
    event.preventDefault();
    event.stopPropagation();

    if (
      event.type === "dragenter" ||
      event.type === "dragover"
    ) {
      setDragActive(true);
    } else if (event.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (event) => {
    event.preventDefault();
    event.stopPropagation();

    setDragActive(false);

    const droppedFile = event.dataTransfer.files?.[0];

    handleSelectedFile(droppedFile);
  };

 
  // FORM UPDATE
 
  const updateField = (key, value) => {
    setForm((prev) => ({
      ...prev,
      [key]: value,
    }));
  };
  // LOG POLLING
  
  useEffect(() => {
    if (!runId) {
      return;
    }

    console.log("Start polling for runId:", runId);

    const interval = setInterval(async () => {
      try {
        const response = await fetch(
          `http://192.168.3.173:9090/logs/${runId}`
        );

        if (!response.ok) {
          clearInterval(interval);
          return;
        }

        const data = await response.json();

        setLogs(data);

        const joined = data.join(" | ");

        if (
          joined.includes(
            "Execution of the Test cases has been completed.."
          ) ||
          joined.includes("Execution Stop time:")
        ) {
          clearInterval(interval);
        }
      } catch (error) {
        console.error("Polling error:", error);
        clearInterval(interval);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [runId]);

   // DOCUMENT DOWNLOAD

  const handleDocumentDownload = async (doc) => {
    try {
      const fileUrl = `${window.location.origin}${doc.url}`;

      const response = await fetch(fileUrl, {
        cache: "no-store",
      });

      if (!response.ok) {
        setStatus(
          `Document not found: ${doc.name} (${response.status})`
        );
        return;
      }

      const contentType =
        response.headers.get("content-type") || "";

      // Prevent downloading Vite's HTML fallback page
      if (contentType.includes("text/html")) {
        setStatus(
          `Document path is wrong or file is missing: ${doc.name}`
        );
        return;
      }

      const blob = await response.blob();

      if (!blob || blob.size === 0) {
        setStatus(
          `Document is empty or unavailable: ${doc.name}`
        );
        return;
      }

      const url = window.URL.createObjectURL(blob);

      const a = document.createElement("a");

      a.href = url;
      a.download =
        doc.url.split("/").pop() || doc.name;

      document.body.appendChild(a);

      a.click();

      document.body.removeChild(a);

      window.URL.revokeObjectURL(url);

      setStatus(`Document downloaded: ${doc.name}`);
    } catch (error) {
      console.error("Document download error:", error);

      setStatus(
        `Unable to download document: ${doc.name}`
      );
    }
  };

   // RUN TESTS
  const runTests = async () => {
    setStatus("");
    setReportUrl("");

    // Validate Excel file
    if (!file) {
      setStatus("Please choose an Excel file.");
      return;
    }

    // Validate Basic Authentication
    if (
      authType === "BASIC" &&
      (!form.username || !form.password)
    ) {
      setStatus(
        "Username and password are required for Basic authentication."
      );
      return;
    }

    // Validate OAuth
    if (
      authType === "OAUTH" &&
      (!form.clientId ||
        !form.clientSecret ||
        !form.tokenUrl)
    ) {
      setStatus(
        "Token URL, Client ID and Client Secret are required for OAuth."
      );
      return;
    }

    // Validate Project
 
if (reportPortalEnabled && !selectedProject) {
  setStatus("Please select or create a project when ReportPortal is enabled.");
  return;
}

    const data = new FormData();

    data.append("file", file);

    data.append("authType", authType);

    data.append("username", form.username);
    data.append("password", form.password);

    data.append("clientId", form.clientId);
    data.append("clientSecret", form.clientSecret);

    data.append("tokenUrl", form.tokenUrl);

    data.append(
      "grantType",
      form.grantType || "client_credentials"
    );

   data.append("projectName", selectedProject ? selectedProject.value : "" );

    // ReportPortal value sent to backend
    data.append("reportPortalEnabled", reportPortalEnabled);

    try {
      setBusy(true);

      setStatus("Running tests...");

      const response = await fetch(
        "http://localhost:9090/run-tests",
        {
          method: "POST",
          body: data,
        }
      );

      if (!response.ok) {
        const message = await response.text();

        throw new Error(
          message || "Execution failed"
        );
      }

      // Get Run ID
      const id = response.headers.get("X-Run-Id");

      if (id) {
        setRunId(id);
      }

      // Get ZIP response
      const blob = await response.blob();

      const url =
        window.URL.createObjectURL(blob);

      // Download automatically
      const a = document.createElement("a");

      a.href = url;
      a.download = "api-test-results.zip";

      document.body.appendChild(a);

      a.click();

      document.body.removeChild(a);

      // Keep URL for manual download
      setReportUrl(url);

      setStatus(
        "Execution completed. Report downloaded."
      );
    } catch (error) {
      console.error("Execution error:", error);

      setStatus(
        error.message || "Execution failed."
      );
    } finally {
      setBusy(false);
    }
  };

  // ============================================================
  // LOAD PROJECTS
  // ============================================================

  useEffect(() => {
    fetch("http://localhost:9090/projects")
      .then((res) => {
        if (!res.ok) {
          throw new Error(
            `Failed to load projects: ${res.status}`
          );
        }

        return res.json();
      })
      .then((data) => {
        const formattedProjects = data.map(
          (project) => ({
            value: project,
            label: project,
          })
        );

        setProjects(formattedProjects);
      })
      .catch((error) => {
        console.error(
          "Failed to load projects:",
          error
        );

        setStatus(
          "Unable to load projects from backend."
        );
      });
  }, []);

  // ============================================================
  // ADD PROJECT
  // ============================================================

  const addProject = async () => {
    const projectName = newProject.trim();

    if (!projectName) {
      setStatus("Please enter project name.");
      return;
    }

    try {
      const response = await fetch(
        "http://localhost:9090/projects",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            name: projectName,
          }),
        }
      );

      if (!response.ok) {
        const message = await response.text();

        throw new Error(
          message || "Unable to add project."
        );
      }

      const updatedProjects =
        await response.json();

      const formatted = updatedProjects.map(
        (project) => ({
          value: project,
          label: project,
        })
      );

      setProjects(formatted);

      const addedProject = formatted.find(
        (project) =>
          project.value === projectName
      );

      if (addedProject) {
        setSelectedProject(addedProject);
      }

      setNewProject("");

      setShowAddProjectModal(false);

      setStatus(
        `Project "${projectName}" added successfully.`
      );
    } catch (error) {
      console.error(
        "Add project error:",
        error
      );

      setStatus(
        error.message ||
          "Unable to add project."
      );
    }
  };

  // ============================================================
  // UI
  // ============================================================

  return (
    <div className="pageWithActions">

      {/* ======================================================
          TOP ACTIONS
      ====================================================== */}

      <div className="topActionsBar">
        <button
          className="documentsBtn"
          onClick={() =>
            setShowDocsModal(true)
          }
        >
          Documents
        </button>
      </div>

      {/* ======================================================
          MAIN CARD
      ====================================================== */}

      <div className="card">

        <h1>API Automation Framework</h1>

        <p className="subtitle">
          Choose Authentication & Upload your Excel File
        </p>

        {/* ====================================================
            AUTHENTICATION TYPE
        ==================================================== */}

        <div className="section">

          <label>
            Authentication Type
          </label>

          <select
            value={authType}
            onChange={(e) =>
              setAuthType(e.target.value)
            }
          >
            <option value="BASIC">
              Basic
            </option>

            <option value="OAUTH">
              OAuth
            </option>
          </select>

        </div>

        {/* ====================================================
            BASIC AUTH
        ==================================================== */}

        {authType === "BASIC" ? (

          <div className="grid two">

            <div>
              <label>
                Username
              </label>

              <input
                value={form.username}
                onChange={(e) =>
                  updateField(
                    "username",
                    e.target.value
                  )
                }
                placeholder="Enter username"
              />
            </div>

            <div>
              <label>
                Password
              </label>

              <input
                type="password"
                value={form.password}
                onChange={(e) =>
                  updateField(
                    "password",
                    e.target.value
                  )
                }
                placeholder="Enter password"
              />
            </div>

          </div>

        ) : (

          /* ==================================================
             OAUTH
          ================================================== */

          <div className="grid two">

            <div>
              <label>
                Token URL
              </label>

              <input
                value={form.tokenUrl}
                onChange={(e) =>
                  updateField(
                    "tokenUrl",
                    e.target.value
                  )
                }
                placeholder="https://.../token"
              />
            </div>

            <div>
              <label>
                Grant Type
              </label>

              <input
                value={form.grantType}
                onChange={(e) =>
                  updateField(
                    "grantType",
                    e.target.value
                  )
                }
                placeholder="client_credentials"
                disabled
              />
            </div>

            <div>
              <label>
                Client ID
              </label>

              <input
                value={form.clientId}
                onChange={(e) =>
                  updateField(
                    "clientId",
                    e.target.value
                  )
                }
                placeholder="Enter client id"
              />
            </div>

            <div className="input-wrapper">

              <label>
                Client Secret
              </label>

              <div className="input-field">

                <input
                  type={
                    showClientSecret
                      ? "text"
                      : "password"
                  }
                  value={form.clientSecret}
                  onChange={(e) =>
                    updateField(
                      "clientSecret",
                      e.target.value
                    )
                  }
                  placeholder="Enter client secret"
                />

                <button
                  type="button"
                  className="toggle-btn"
                  onClick={() =>
                    setShowClientSecret(
                      (prev) => !prev
                    )
                  }
                >
                  {showClientSecret
                    ? "Hide"
                    : "Show"}
                </button>

              </div>

            </div>

          </div>
        )}

        {/* ====================================================
            PROJECT SECTION
        ==================================================== */}

        <div className="section">

          <label>
            Project Name
          </label>

          <div className="projectSelectRow">

            <div className="projectDropdown">

              <Select
                options={projects}
                value={selectedProject}
                onChange={setSelectedProject}
                isSearchable
                placeholder="Search or select project..."
              />

            </div>

            <button
              type="button"
              className="addProjectBtn"
              onClick={() =>
                setShowAddProjectModal(true)
              }
            >
              + Add Project
            </button>

          </div>

        </div>

        {/* ====================================================
            REPORT PORTAL CHECKBOX
           
        ==================================================== */}

        <div className="section">

          <label>

            <input
              type="checkbox"
              checked={reportPortalEnabled}
              onChange={(e) =>
                setReportPortalEnabled(
                  e.target.checked
                )
              }
            />

            {" "}Send results to ReportPortal

          </label>

        </div>

        {/* ====================================================
            EXCEL FILE
        ==================================================== */}

        <div className="section">

          <label>
            Excel File
          </label>

          <div
            className={`dropzone ${
              dragActive ? "active" : ""
            }`}
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            onClick={() =>
              fileInputRef.current?.click()
            }
            style={{
              cursor: "pointer",
            }}
          >

            <p>

              {file
                ? `Selected file: ${file.name}`
                : "Drag & drop your Excel file here, or click to browse"}

            </p>

            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls"
              style={{
                display: "none",
              }}
              onChange={onFileChange}
            />

          </div>

          <small>

            <b>
              Expected sheet columns:
            </b>{" "}

            {REQUIRED_COLUMNS.join(", ")}

          </small>

        </div>

        {/* ====================================================
            RUN TEST BUTTON
        ==================================================== */}

        <button
          className="runBtn"
          disabled={!canRun}
          onClick={runTests}
        >
          {busy
            ? "Running..."
            : "Run Tests"}
        </button>

        {/* ====================================================
            RELOAD NOTICE
        ==================================================== */}

        <div className="reloadNotice">
          ↻ Please reload the page after each run.
        </div>

        {/* ====================================================
            STATUS
        ==================================================== */}

        {status ? (
          <div className="status">
            {status}
          </div>
        ) : null}

        {/* ====================================================
            GENERATED REPORT
        ==================================================== */}

        {reportUrl ? (

          <div className="section">

            <a
              href={reportUrl}
              target="_blank"
              rel="noreferrer"
            >
              Download generated report
            </a>

          </div>

        ) : null}

      </div>

      {/* ======================================================
          DOCUMENTS MODAL
      ====================================================== */}

      {showDocsModal && (

        <div
          className="modalOverlay"
          onClick={() =>
            setShowDocsModal(false)
          }
        >

          <div
            className="modalCard"
            onClick={(e) =>
              e.stopPropagation()
            }
          >

            <div className="modalHeader">

              <h2>
                API Testing Documents
              </h2>

              <button
                className="closeModalBtn"
                onClick={() =>
                  setShowDocsModal(false)
                }
              >
                ✕
              </button>

            </div>

            <div className="documentsList">

              {API_TESTING_DOCUMENTS.map(
                (doc, index) => (

                  <div
                    className="documentRow"
                    key={index}
                  >

                    <span>
                      {doc.name}
                    </span>

                    <button
                      type="button"
                      className="downloadDocBtn"
                      onClick={() =>
                        handleDocumentDownload(
                          doc
                        )
                      }
                    >
                      Download
                    </button>

                  </div>

                )
              )}

            </div>

          </div>

        </div>

      )}

      {/* 
          ADD PROJECT MODAL
       */}

      {showAddProjectModal && (

        <div
          className="modalOverlay"
          onClick={() =>
            setShowAddProjectModal(false)
          }
        >

          <div
            className="modalCard"
            onClick={(e) =>
              e.stopPropagation()
            }
          >

            <div className="modalHeader">

              <h2>
                Add Project
              </h2>

              <button
                className="closeModalBtn"
                onClick={() =>
                  setShowAddProjectModal(false)
                }
              >
                ✕
              </button>

            </div>

            <div className="section">

              <label>
                Project Name
              </label>

              <input
                value={newProject}
                placeholder="Enter project name"
                onChange={(e) =>
                  setNewProject(
                    e.target.value
                  )
                }
              />

            </div>

            <button
              className="runBtn"
              onClick={addProject}
            >
              Save Project
            </button>

          </div>

        </div>

      )}

    </div>
  );
}