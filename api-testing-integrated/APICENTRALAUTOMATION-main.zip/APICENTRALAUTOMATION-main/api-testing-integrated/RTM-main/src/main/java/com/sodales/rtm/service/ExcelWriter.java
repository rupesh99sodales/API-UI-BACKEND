package com.sodales.rtm.service;

import com.sodales.rtm.model.RtmDataset;
import com.sodales.rtm.model.Story;
import com.sodales.rtm.model.TestCaseInfo;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Set;

@Service
public class ExcelWriter {

    private static final String MATRIX = "RTM Matrix";
    private static final int META_COLS = 6;   // A..F before the test-case columns

    private static final byte[] NAVY    = rgb(0x1F, 0x30, 0x4A);
    private static final byte[] GREY    = rgb(0xF2, 0xF4, 0xF7);
    private static final byte[] REDBG   = rgb(0xF9, 0xD2, 0xD2);
    private static final byte[] REDTX   = rgb(0xB0, 0x00, 0x00);
    private static final byte[] GREENTX = rgb(0x1E, 0x7A, 0x34);
    private static final byte[] BORDER  = rgb(0xD0, 0xD5, 0xDD);
    private static final byte[] MARKBG  = rgb(0xD6, 0xEC, 0xD9);

    public byte[] toXlsx(RtmDataset d) throws IOException {
        try (XSSFWorkbook wb = new XSSFWorkbook();
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            S s = new S(wb);
            writeMatrix(wb, s, d);
            writeMatches(wb, s, d);
            writeTestCases(wb, s, d);
            Sheet summary = writeSummary(wb, s, d);
            wb.setSheetOrder("Summary", 0);
            wb.setActiveSheet(wb.getSheetIndex(summary));
            wb.write(out);
            return out.toByteArray();
        }
    }

    // ---- RTM Matrix ----------------------------------------------------

    private void writeMatrix(XSSFWorkbook wb, S s, RtmDataset d) {
        Sheet sh = wb.createSheet(MATRIX);
        sh.setDisplayGridlines(false);
        int n = d.testCaseCount();
        int lastRow = 1 + d.storyCount();                 // 1-based Excel row of last story
        String firstTc = CellReference.convertNumToColString(META_COLS);
        String lastTc  = CellReference.convertNumToColString(META_COLS + Math.max(n, 1) - 1);

        // header row
        Row h = sh.createRow(0); h.setHeightInPoints(70);
        String[] meta = {"User Story ID", "Title", "Acceptance Criteria", "State",
                "Linked Count", "Coverage"};
        for (int i = 0; i < meta.length; i++) put(h, i, meta[i], s.header);
        for (int j = 0; j < n; j++) put(h, META_COLS + j, d.testCases().get(j).id(), s.tcHeader);

        // story rows
        int rowIdx = 1;
        for (Story st : d.stories()) {
            int excelRow = rowIdx + 1;                     // 1-based for formulas
            boolean zebra = (rowIdx % 2 == 0);
            CellStyle text = zebra ? s.cellZebra : s.cell;
            CellStyle wrap = zebra ? s.cellWrapZebra : s.cellWrap;
            CellStyle ctr  = zebra ? s.centerZebra : s.center;

            Row row = sh.createRow(rowIdx++);
            put(row, 0, st.id(), text);
            put(row, 1, nz(st.title()), wrap);
            put(row, 2, nz(st.acceptanceCriteria()), wrap);
            put(row, 3, nz(st.state()), text);

            Cell count = row.createCell(4);
            if (n > 0) count.setCellFormula("COUNTA(" + firstTc + excelRow + ":" + lastTc + excelRow + ")");
            else count.setCellValue(0);
            count.setCellStyle(ctr);

            Cell cov = row.createCell(5);
            cov.setCellFormula("IF(E" + excelRow + ">0,\"COVERED\",\"UNCOVERED\")");
            cov.setCellStyle(ctr);

            Set<String> linked = d.storyToTests().get(st.id());
            for (int j = 0; j < n; j++) {
                boolean x = linked != null && linked.contains(d.testCases().get(j).id());
                Cell mark = row.createCell(META_COLS + j);   // BLANK by default
                if (x) mark.setCellValue("X");               // only ticked cells get a value
                mark.setCellStyle(x ? (zebra ? s.markZebra : s.mark) : (zebra ? s.gridZebra : s.grid));
            }
        }

        // widths + freeze + print
        int[] mw = {14, 30, 40, 11, 12, 13};
        for (int i = 0; i < META_COLS; i++) sh.setColumnWidth(i, mw[i] * 256);
        for (int j = 0; j < n; j++) sh.setColumnWidth(META_COLS + j, 5 * 256);
        sh.createFreezePane(META_COLS, 1);
        printSetup(sh, true);
        sh.setRepeatingRows(CellRangeAddress.valueOf("1:1"));

        // conditional formatting: red when a story row is UNCOVERED, green text when COVERED
        if (lastRow >= 2) {
            SheetConditionalFormatting scf = sh.getSheetConditionalFormatting();
            String metaRange = "A2:F" + lastRow;

            ConditionalFormattingRule red = scf.createConditionalFormattingRule("$F2=\"UNCOVERED\"");
            PatternFormatting rp = red.createPatternFormatting();
            rp.setFillBackgroundColor(IndexedColors.ROSE.getIndex());
            rp.setFillPattern(PatternFormatting.SOLID_FOREGROUND);
            FontFormatting rf = red.createFontFormatting();
            rf.setFontColorIndex(IndexedColors.DARK_RED.getIndex());
            rf.setFontStyle(false, true);

            ConditionalFormattingRule green = scf.createConditionalFormattingRule("$F2=\"COVERED\"");
            FontFormatting gf = green.createFontFormatting();
            gf.setFontColorIndex(IndexedColors.GREEN.getIndex());
            gf.setFontStyle(false, true);

            scf.addConditionalFormatting(
                    new CellRangeAddress[]{CellRangeAddress.valueOf(metaRange)}, red, green);
        }
    }

    // ---- Matches (keyword evidence) -----------------------------------

    private void writeMatches(XSSFWorkbook wb, S s, RtmDataset d) {
        Sheet sh = wb.createSheet("Matches");
        sh.setDisplayGridlines(false);
        String[] headers = {"Test Case ID", "Test Title", "User Story ID", "Story Title",
                "Source", "Score", "Evidence"};
        Row h = sh.createRow(0); h.setHeightInPoints(22);
        for (int i = 0; i < headers.length; i++) put(h, i, headers[i], s.header);

        int rowIdx = 1;
        for (com.sodales.rtm.model.Match m : d.matches()) {
            boolean zebra = (rowIdx % 2 == 0);
            boolean isLink = "Link".equalsIgnoreCase(m.source());
            CellStyle text = zebra ? s.cellZebra : s.cell;
            CellStyle wrap = zebra ? s.cellWrapZebra : s.cellWrap;
            CellStyle ctr  = zebra ? s.centerZebra : s.center;
            Row row = sh.createRow(rowIdx++);
            put(row, 0, m.testId(), text);
            put(row, 1, nz(m.testTitle()), wrap);
            put(row, 2, m.storyId(), text);
            put(row, 3, nz(m.storyTitle()), wrap);
            // Source: link matches (authoritative) shown green; keyword shown normal
            put(row, 4, m.source(), isLink ? s.statusGreen : ctr);
            Cell sc = row.createCell(5);
            if (isLink) sc.setBlank(); else sc.setCellValue(m.score());  // score only meaningful for keyword
            sc.setCellStyle(ctr);
            put(row, 6, nz(m.evidence()), wrap);
        }
        int[] w = {14, 32, 14, 32, 10, 8, 34};
        for (int i = 0; i < w.length; i++) sh.setColumnWidth(i, w[i] * 256);
        sh.createFreezePane(0, 1);
        if (rowIdx > 1) sh.setAutoFilter(new CellRangeAddress(0, rowIdx - 1, 0, headers.length - 1));
        else put(sh.createRow(1), 0, "No matches (no explicit links, and no keyword match at the threshold).", s.cell);
        printSetup(sh, true);
        sh.setRepeatingRows(CellRangeAddress.valueOf("1:1"));
    }

    // ---- Test Cases reference -----------------------------------------

    private void writeTestCases(XSSFWorkbook wb, S s, RtmDataset d) {
        Sheet sh = wb.createSheet("Test Cases");
        sh.setDisplayGridlines(false);
        String[] headers = {"Test Case ID", "Title", "State"};
        Row h = sh.createRow(0); h.setHeightInPoints(22);
        for (int i = 0; i < headers.length; i++) put(h, i, headers[i], s.header);
        int rowIdx = 1;
        for (TestCaseInfo tc : d.testCases()) {
            boolean zebra = (rowIdx % 2 == 0);
            Row row = sh.createRow(rowIdx++);
            put(row, 0, tc.id(), zebra ? s.cellZebra : s.cell);
            put(row, 1, nz(tc.title()), zebra ? s.cellWrapZebra : s.cellWrap);
            put(row, 2, nz(tc.state()), zebra ? s.cellZebra : s.cell);
        }
        int[] w = {16, 52, 14};
        for (int i = 0; i < w.length; i++) sh.setColumnWidth(i, w[i] * 256);
        sh.createFreezePane(0, 1);
        printSetup(sh, false);
        sh.setRepeatingRows(CellRangeAddress.valueOf("1:1"));
    }

    // ---- Summary -------------------------------------------------------

    private Sheet writeSummary(XSSFWorkbook wb, S s, RtmDataset d) {
        Sheet sh = wb.createSheet("Summary");
        sh.setDisplayGridlines(false);
        int lastRow = 1 + d.storyCount();
        String covRange = "'" + MATRIX + "'!$F$2:$F$" + Math.max(2, lastRow);

        Row t = sh.createRow(0); t.setHeightInPoints(26);
        merge(sh, 0, 0, 0, 3, s.title); put(t, 0, "Requirements Traceability Matrix", s.title);
        Row sub = sh.createRow(1); sub.setHeightInPoints(16);
        merge(sh, 1, 1, 0, 3, s.subtitle);
        put(sub, 0, "Azure DevOps  \u2022  mark X where a test case validates a user story", s.subtitle);
        Row gen = sh.createRow(2); merge(sh, 2, 2, 0, 3, s.meta);
        put(gen, 0, "Generated " + LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("dd MMM yyyy, HH:mm")), s.meta);

        int row = 4;
        Row hdr = sh.createRow(row++);
        put(hdr, 0, "Metric", s.kpiHead); put(hdr, 1, "Value", s.kpiHead);

        row = kpiValue(sh, s, row, "User-story files merged", d.storyFileCount());
        row = kpiValue(sh, s, row, "Test-case files merged", d.testFileCount());
        row = kpiValue(sh, s, row, "Total user stories", d.storyCount());
        row = kpiValue(sh, s, row, "Total test cases", d.testCaseCount());
        row = kpiValue(sh, s, row, "Mapped by link (authoritative)", d.matchedByLink());
        row = kpiValue(sh, s, row, "Mapped by keyword (suggested)", d.matchedByKeyword());
        row = kpiValue(sh, s, row, "Test cases with no match", d.unmatchedTestCases());
        sh.createRow(row++);
        int coveredRow = row + 1;
        row = kpiFormula(sh, s, row, "Covered (\u2265 1 test marked)",
                "COUNTIF(" + covRange + ",\"COVERED\")", false);
        row = kpiFormula(sh, s, row, "Uncovered (no test marked)",
                "COUNTIF(" + covRange + ",\"UNCOVERED\")", true);
        row = kpiPercent(sh, s, row, "Coverage",
                "IFERROR(B" + coveredRow + "/(B" + coveredRow + "+B" + (coveredRow + 1) + "),0)");
        sh.createRow(row++);
        Row mode = sh.createRow(row++);
        put(mode, 0, "Mapping mode", s.kpiLabel);
        put(mode, 1, d.mappingMode(), s.kpiText);
        Row note = sh.createRow(row++);
        put(note, 0, "Note", s.kpiLabel);
        put(note, 1, "Link matches are authoritative; keyword matches are suggestions \u2014 "
                + "see the Matches sheet (Source column) and confirm/clear X.", s.kpiText);

        row++;
        Row legTitle = sh.createRow(row++); put(legTitle, 0, "Legend", s.kpiLabel);
        Row leg = sh.createRow(row++);
        put(leg, 0, "", s.redSwatch);
        put(leg, 1, "Uncovered \u2014 user story has no test case marked yet", s.kpiText);

        sh.setColumnWidth(0, 34 * 256); sh.setColumnWidth(1, 58 * 256);
        sh.setColumnWidth(2, 3 * 256);  sh.setColumnWidth(3, 3 * 256);
        printSetup(sh, false);
        return sh;
    }

    // ---- helpers -------------------------------------------------------

    private int kpiValue(Sheet sh, S s, int rowIdx, String k, long v) {
        Row row = sh.createRow(rowIdx);
        put(row, 0, k, s.kpiLabel);
        Cell c = row.createCell(1); c.setCellValue(v); c.setCellStyle(s.kpiNum);
        return rowIdx + 1;
    }

    private int kpiFormula(Sheet sh, S s, int rowIdx, String k, String formula, boolean red) {
        Row row = sh.createRow(rowIdx);
        put(row, 0, k, red ? s.kpiLabelRed : s.kpiLabel);
        Cell c = row.createCell(1); c.setCellFormula(formula); c.setCellStyle(red ? s.kpiNumRed : s.kpiNum);
        return rowIdx + 1;
    }

    private int kpiPercent(Sheet sh, S s, int rowIdx, String k, String formula) {
        Row row = sh.createRow(rowIdx);
        put(row, 0, k, s.kpiLabel);
        Cell c = row.createCell(1); c.setCellFormula(formula); c.setCellStyle(s.kpiPct);
        return rowIdx + 1;
    }

    private void printSetup(Sheet sh, boolean landscape) {
        sh.setFitToPage(true);
        sh.setMargin(Sheet.LeftMargin, 0.3);
        sh.setMargin(Sheet.RightMargin, 0.3);
        PrintSetup ps = sh.getPrintSetup();
        ps.setLandscape(landscape);
        ps.setFitWidth((short) 1);
        ps.setFitHeight((short) 0);
    }

    private void put(Row row, int col, String value, CellStyle style) {
        Cell c = row.createCell(col);
        c.setCellValue(value == null ? "" : value);
        c.setCellStyle(style);
    }

    private void merge(Sheet sh, int r1, int r2, int c1, int c2, CellStyle style) {
        sh.addMergedRegion(new CellRangeAddress(r1, r2, c1, c2));
        for (int r = r1; r <= r2; r++) {
            Row row = sh.getRow(r); if (row == null) row = sh.createRow(r);
            for (int c = c1; c <= c2; c++) {
                Cell cell = row.getCell(c); if (cell == null) cell = row.createCell(c);
                cell.setCellStyle(style);
            }
        }
    }

    private static String nz(String s) { return s == null ? "" : s; }
    private static byte[] rgb(int r, int g, int b) { return new byte[]{(byte) r, (byte) g, (byte) b}; }

    /** Cell styles. */
    private static final class S {
        final CellStyle title, subtitle, meta;
        final CellStyle kpiHead, kpiLabel, kpiLabelRed, kpiText, kpiNum, kpiNumRed, kpiPct;
        final CellStyle header, tcHeader;
        final CellStyle cell, cellZebra, cellWrap, cellWrapZebra, center, centerZebra;
        final CellStyle grid, gridZebra, mark, markZebra, redSwatch, statusGreen;

        S(XSSFWorkbook wb) {
            String ff = "Calibri";
            Font titleF = font(wb, ff, 16, true, NAVY);
            Font subF   = font(wb, ff, 11, false, rgb(0x55, 0x5F, 0x6D));
            Font metaF  = font(wb, ff, 9,  false, rgb(0x8A, 0x93, 0xA0));
            Font whiteB = font(wb, ff, 11, true, rgb(0xFF, 0xFF, 0xFF));
            Font whiteS = font(wb, ff, 9,  true, rgb(0xFF, 0xFF, 0xFF));
            Font baseF  = font(wb, ff, 10, false, rgb(0x20, 0x25, 0x2B));
            Font boldF  = font(wb, ff, 10, true, rgb(0x20, 0x25, 0x2B));
            Font redF   = font(wb, ff, 10, true, REDTX);
            Font markF  = font(wb, ff, 10, true, GREENTX);

            title = plain(wb, titleF, null, false);
            title.setAlignment(HorizontalAlignment.LEFT); title.setVerticalAlignment(VerticalAlignment.CENTER);
            subtitle = plain(wb, subF, null, false);
            meta = plain(wb, metaF, null, false);

            kpiHead = boxed(wb, whiteB, NAVY, false);
            kpiLabel = boxed(wb, boldF, GREY, false);
            kpiLabelRed = boxed(wb, redF, REDBG, false);
            kpiText = boxed(wb, baseF, null, false);
            kpiNum = boxed(wb, baseF, null, false); kpiNum.setAlignment(HorizontalAlignment.RIGHT);
            kpiNumRed = boxed(wb, redF, REDBG, false); kpiNumRed.setAlignment(HorizontalAlignment.RIGHT);
            kpiPct = boxed(wb, boldF, null, false); kpiPct.setAlignment(HorizontalAlignment.RIGHT);
            kpiPct.setDataFormat(wb.createDataFormat().getFormat("0.0%"));

            header = boxed(wb, whiteB, NAVY, false);
            header.setAlignment(HorizontalAlignment.LEFT); header.setVerticalAlignment(VerticalAlignment.CENTER);
            tcHeader = boxed(wb, whiteS, NAVY, false);
            tcHeader.setAlignment(HorizontalAlignment.CENTER);
            tcHeader.setVerticalAlignment(VerticalAlignment.BOTTOM);
            tcHeader.setRotation((short) 90);

            cell = boxed(wb, baseF, null, false);
            cellZebra = boxed(wb, baseF, GREY, false);
            cellWrap = boxed(wb, baseF, null, true);
            cellWrapZebra = boxed(wb, baseF, GREY, true);
            center = boxed(wb, baseF, null, false); center.setAlignment(HorizontalAlignment.CENTER);
            centerZebra = boxed(wb, baseF, GREY, false); centerZebra.setAlignment(HorizontalAlignment.CENTER);

            grid = boxed(wb, baseF, null, false); grid.setAlignment(HorizontalAlignment.CENTER);
            gridZebra = boxed(wb, baseF, GREY, false); gridZebra.setAlignment(HorizontalAlignment.CENTER);
            mark = boxed(wb, markF, MARKBG, false); mark.setAlignment(HorizontalAlignment.CENTER);
            markZebra = boxed(wb, markF, MARKBG, false); markZebra.setAlignment(HorizontalAlignment.CENTER);
            redSwatch = boxed(wb, baseF, REDBG, false);
            statusGreen = boxed(wb, markF, null, false); statusGreen.setAlignment(HorizontalAlignment.CENTER);
        }

        private static Font font(XSSFWorkbook wb, String name, int pts, boolean bold, byte[] color) {
            XSSFFont f = wb.createFont();
            f.setFontName(name); f.setFontHeightInPoints((short) pts); f.setBold(bold);
            f.setColor(new XSSFColor(color, null));
            return f;
        }

        private static CellStyle plain(XSSFWorkbook wb, Font f, byte[] fill, boolean wrap) {
            XSSFCellStyle cs = wb.createCellStyle();
            cs.setFont(f); cs.setVerticalAlignment(VerticalAlignment.TOP);
            if (wrap) cs.setWrapText(true);
            if (fill != null) { cs.setFillForegroundColor(new XSSFColor(fill, null)); cs.setFillPattern(FillPatternType.SOLID_FOREGROUND); }
            return cs;
        }

        private static CellStyle boxed(XSSFWorkbook wb, Font f, byte[] fill, boolean wrap) {
            XSSFCellStyle cs = (XSSFCellStyle) plain(wb, f, fill, wrap);
            XSSFColor b = new XSSFColor(BORDER, null);
            cs.setBorderTop(BorderStyle.THIN);    cs.setTopBorderColor(b);
            cs.setBorderBottom(BorderStyle.THIN); cs.setBottomBorderColor(b);
            cs.setBorderLeft(BorderStyle.THIN);   cs.setLeftBorderColor(b);
            cs.setBorderRight(BorderStyle.THIN);  cs.setRightBorderColor(b);
            return cs;
        }
    }
}
