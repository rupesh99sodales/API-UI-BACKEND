import { NavLink, Outlet } from "react-router-dom";
import logo from "../assets/sodales-Logos_White.png";
import "../styles/global.css";

export default function MainLayout() {
  return (
    <div className="appShell">
      <div className="navbar">
        <div className="nav-left">
          <div className="header">
            <img src={logo} alt="Logo" className="logo" />
          </div>
          <span className="nav-title">QA Utilities For Testing </span>
        </div>

        <nav className="nav-right">
          <NavLink
            to="/api-testing"
            className={({ isActive }) =>
              `navTab ${isActive ? "navTabActive" : ""}`
            }
          >
            API Automation
          </NavLink>

          <NavLink
            to="/testcase-generator"
            className={({ isActive }) =>
              `navTab ${isActive ? "navTabActive" : ""}`
            }
          >
            AI Test Case Generator
          </NavLink>

          <NavLink
            to="/rtm-generator"
            className={({ isActive }) =>
              `navTab ${isActive ? "navTabActive" : ""}`
            }
          >
            RTM Generator
          </NavLink>

          <NavLink
            to="/convert"
            className={({ isActive }) =>
              `navTab ${isActive ? "navTabActive" : ""}`
            }
          >
            Template Converter
          </NavLink>

           <NavLink
            to="/payload-encrypt-decrypt"
            className={({ isActive }) =>
              `navTab ${isActive ? "navTabActive" : ""}`
            }
          >
            Encryption/Decryption
          </NavLink>

            <NavLink
            to="/plugin"
            className={({ isActive }) =>
              `navTab ${isActive ? "navTabActive" : ""}`
            }
          >
            Plugins / Utilities
          </NavLink>
        </nav>
      </div>

      <main className="mainContent">
        <Outlet />
      </main>

      <footer className="footer">
        © {new Date().getFullYear()} Sodales Solutions. All Rights Reserved.
      </footer>
    </div>
  );
}
