package com.sodales.rtm.service;

import com.sodales.rtm.csv.CsvReader;
import com.sodales.rtm.csv.CsvTable;
import com.sodales.rtm.model.*;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.*;

/**
 * Merges one-or-more user-story CSVs and one-or-more test-case CSVs (ADO exports)
 * into a single RTM dataset. Mapping is HYBRID and decided per test case:
 *
 *   - if the test case has an explicit link (a mapping column such as
 *     "User Story ID" / "Tested By" / "Parent" holds a story ID), that link is
 *     used verbatim  ->  source = "Link" (authoritative);
 *   - otherwise the test case is matched by KEYWORD overlap of title +
 *     description + tags  ->  source = "Keyword" (suggested).
 *
 * No database. Any number of files may be uploaded for each side.
 */
@Service
public class TraceabilityService {

    public static final int DEFAULT_THRESHOLD = 3;
    public static final String SOURCE_LINK = "Link";
    public static final String SOURCE_KEYWORD = "Keyword";

    private static final String[] ID_CANDIDATES    = {"ID", "Work Item ID", "Id"};
    private static final String[] TITLE_CANDIDATES = {"Title", "Work Item Title", "Name"};
    private static final String[] STATE_CANDIDATES = {"State", "Status"};
    private static final String[] AC_CANDIDATES    = {
            "Acceptance Criteria", "AcceptanceCriteria", "Acceptance criteria", "Acceptance", "AC"};
    private static final String[] DESC_CANDIDATES  = {
            "Description", "Details", "Summary", "Steps", "Step Action"};
    private static final String[] TAG_CANDIDATES   = {"Tags", "Tag"};
    private static final String[] LINK_CANDIDATES  = {
            "User Story ID", "User Story", "Story ID", "Story",
            "Requirement ID", "Requirement", "Tested Requirement", "Tested User Story",
            "Parent", "Parent ID", "Related", "Related ID",
            "Linked Work Item", "Linked Work Items", "Work Item ID", "Tested By"};

    /** Column-name overrides; any null field falls back to auto-detection. */
    public record Columns(String storyId, String storyTitle, String storyState,
                          String storyAcColumn, String storyDescColumn, String storyTagColumn,
                          String testId, String testTitle, String testDescColumn,
                          String testTagColumn, String testLinkColumn) {
        public static Columns auto() {
            return new Columns(null, null, null, null, null, null, null, null, null, null, null);
        }
    }

    public RtmDataset generate(List<MultipartFile> storyFiles,
                               List<MultipartFile> testFiles,
                               Columns cols, int minScore) throws IOException {

        if (empty(storyFiles)) throw new IllegalArgumentException(
                "Attach at least one user-stories CSV (form field 'stories').");
        if (empty(testFiles)) throw new IllegalArgumentException(
                "Attach at least one test-cases CSV (form field 'testcases').");
        int threshold = minScore > 0 ? minScore : DEFAULT_THRESHOLD;

        // ---- merge stories (across all story files) ----
        LinkedHashMap<String, Story> stories = new LinkedHashMap<>();
        int storyFileCount = 0;
        for (MultipartFile f : storyFiles) {
            if (f == null || f.isEmpty()) continue;
            storyFileCount++;
            CsvTable t = readTable(f, "stories");
            String cId    = require(pick(cols.storyId(), t, ID_CANDIDATES), "story ID", t, ID_CANDIDATES);
            String cTitle = pick(cols.storyTitle(), t, TITLE_CANDIDATES);
            String cState = pick(cols.storyState(), t, STATE_CANDIDATES);
            String cAc    = pick(cols.storyAcColumn(), t, AC_CANDIDATES);
            String cDesc  = pick(cols.storyDescColumn(), t, DESC_CANDIDATES);
            String cTags  = pick(cols.storyTagColumn(), t, TAG_CANDIDATES);
            for (Map<String, String> row : t.rows()) {
                String id = norm(CsvTable.value(row, cId));
                if (id == null) continue;
                stories.putIfAbsent(id, new Story(id,
                        CsvTable.value(row, cTitle),
                        htmlToText(CsvTable.value(row, cDesc)),
                        htmlToText(CsvTable.value(row, cAc)),
                        CsvTable.value(row, cState),
                        CsvTable.value(row, cTags)));
            }
        }

        // ---- merge test cases + capture any explicit links ----
        LinkedHashMap<String, TestCaseInfo> tests = new LinkedHashMap<>();
        Map<String, List<String>> testLinks = new LinkedHashMap<>();   // testId -> explicit story ids
        String linkColLabel = null;
        int testFileCount = 0;
        for (MultipartFile f : testFiles) {
            if (f == null || f.isEmpty()) continue;
            testFileCount++;
            CsvTable t = readTable(f, "test cases");
            String cId    = require(pick(cols.testId(), t, ID_CANDIDATES), "test-case ID", t, ID_CANDIDATES);
            String cTitle = pick(cols.testTitle(), t, TITLE_CANDIDATES);
            String cTags  = pick(cols.testTagColumn(), t, TAG_CANDIDATES);
            String cDesc  = pick(cols.testDescColumn(), t, DESC_CANDIDATES);
            String cState = pick(null, t, STATE_CANDIDATES);
            String cLink  = pick(cols.testLinkColumn(), t, LINK_CANDIDATES);   // may be null
            if (cLink != null && linkColLabel == null) linkColLabel = cLink;
            for (Map<String, String> row : t.rows()) {
                String id = norm(CsvTable.value(row, cId));
                if (id == null) continue;
                tests.putIfAbsent(id, new TestCaseInfo(id,
                        CsvTable.value(row, cTitle),
                        CsvTable.value(row, cState),
                        CsvTable.value(row, cTags),
                        htmlToText(CsvTable.value(row, cDesc))));
                if (cLink != null) {
                    testLinks.putIfAbsent(id, splitIds(CsvTable.value(row, cLink)));
                }
            }
        }

        List<Story> storyList = new ArrayList<>(stories.values());
        List<TestCaseInfo> testList = new ArrayList<>(tests.values());
        Map<String, Story> storyById = new HashMap<>();
        for (Story st : storyList) storyById.put(st.id(), st);

        // ---- hybrid mapping ----
        Map<String, Set<String>> storyToTests = new LinkedHashMap<>();
        List<Match> matches = new ArrayList<>();
        Set<String> matchedTests = new HashSet<>();
        int byLink = 0, byKeyword = 0;
        boolean anyLink = false;
        String linkLabel = linkColLabel == null ? "link column" : "'" + linkColLabel + "'";

        for (TestCaseInfo tc : testList) {
            List<String> explicit = testLinks.getOrDefault(tc.id(), List.of());
            if (!explicit.isEmpty()) {
                // explicit mapping present -> use it (authoritative)
                anyLink = true;
                for (String sid : explicit) {
                    Story st = storyById.get(sid);
                    if (st != null) {
                        storyToTests.computeIfAbsent(sid, k -> new LinkedHashSet<>()).add(tc.id());
                        matches.add(new Match(tc.id(), tc.title(), st.id(), st.title(),
                                SOURCE_LINK, 0, "linked via " + linkLabel));
                        matchedTests.add(tc.id());
                        byLink++;
                    }
                }
            } else {
                // no explicit link -> keyword matching
                for (Story st : storyList) {
                    String storyText = joinText(st.description(), st.acceptanceCriteria());
                    KeywordMatcher.Result r = KeywordMatcher.score(
                            st.title(), storyText, st.tags(),
                            tc.title(), tc.description(), tc.tags());
                    if (r.matches(threshold)) {
                        storyToTests.computeIfAbsent(st.id(), k -> new LinkedHashSet<>()).add(tc.id());
                        matches.add(new Match(tc.id(), tc.title(), st.id(), st.title(),
                                SOURCE_KEYWORD, r.score(), keywordEvidence(r)));
                        matchedTests.add(tc.id());
                        byKeyword++;
                    }
                }
            }
        }
        matches.sort(Comparator.comparing(Match::storyId).thenComparing(Match::testId));
        int unmatched = testList.size() - matchedTests.size();

        String mode = anyLink
                ? "Hybrid \u2014 explicit link where present, else keyword (threshold " + threshold + ")"
                : "Keyword (title + description + tags), threshold " + threshold;

        return new RtmDataset(storyFileCount, testFileCount,
                storyList.size(), testList.size(),
                mode, threshold, byLink, byKeyword, unmatched,
                storyList, testList, storyToTests, matches);
    }

    // ---- helpers -------------------------------------------------------

    private String keywordEvidence(KeywordMatcher.Result r) {
        StringBuilder sb = new StringBuilder();
        if (!r.words().isEmpty()) sb.append("words: ").append(String.join(", ", r.words()));
        if (!r.tags().isEmpty()) {
            if (sb.length() > 0) sb.append("  \u00b7  ");
            sb.append("tags: ").append(String.join(", ", r.tags()));
        }
        return sb.toString();
    }

    private boolean empty(List<MultipartFile> files) {
        if (files == null || files.isEmpty()) return true;
        return files.stream().allMatch(f -> f == null || f.isEmpty());
    }

    private CsvTable readTable(MultipartFile file, String label) throws IOException {
        CsvTable t = CsvReader.read(file.getInputStream());
        if (t.headers().isEmpty())
            throw new IllegalArgumentException("A " + label + " CSV has no header row");
        return t;
    }

    private String pick(String override, CsvTable table, String... candidates) {
        if (override != null && !override.isBlank()) {
            String resolved = table.resolveHeader(override);
            if (resolved == null)
                throw new IllegalArgumentException(
                        "Column '" + override + "' not found. Available: " + table.headers());
            return resolved;
        }
        return table.resolveHeader(candidates);
    }

    private String require(String resolved, String what, CsvTable table, String... candidates) {
        if (resolved == null)
            throw new IllegalArgumentException(
                    "Could not find a " + what + " column. Tried " + Arrays.toString(candidates)
                    + ". Available headers: " + table.headers() + ". Pass the correct name explicitly.");
        return resolved;
    }

    private List<String> splitIds(String raw) {
        if (raw == null || raw.isBlank()) return List.of();
        List<String> ids = new ArrayList<>();
        for (String p : raw.split("[;,\\s]+")) {
            String id = norm(p);
            if (id != null) ids.add(id);
        }
        return ids;
    }

    private String norm(String s) {
        if (s == null) return null;
        String t = s.trim();
        return t.isEmpty() ? null : t;
    }

    private String joinText(String a, String b) {
        String x = a == null ? "" : a;
        String y = b == null ? "" : b;
        return (x + "\n" + y).trim();
    }

    private String htmlToText(String html) {
        if (html == null || html.isBlank()) return "";
        String s = html;
        s = s.replaceAll("(?i)<\\s*li[^>]*>", "\u2022 ");
        s = s.replaceAll("(?i)<\\s*/\\s*(li|p|div|br|ul|ol|tr)\\s*>", "\n");
        s = s.replaceAll("(?i)<\\s*br\\s*/?\\s*>", "\n");
        s = s.replaceAll("<[^>]+>", "");
        s = s.replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<")
             .replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'");
        s = s.replaceAll("[ \t]+\n", "\n").replaceAll("\n{3,}", "\n\n").trim();
        return s;
    }
}
