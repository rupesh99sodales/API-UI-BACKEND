import { useState, useRef } from "react";
import "../styles/converter.css";

export default function Converter() {
  const [conversionType, setConversionType] = useState("excelToPostman");
  const [collectionName, setCollectionName] = useState("Generated Collection");
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState([]);
  const [downloadUrl, setDownloadUrl] = useState("");
  const [success, setSuccess] = useState("");

  const fileInputRef = useRef(null);

  const removeFile = () => {
    setFile(null);

    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const resetState = () => {
    setErrors([]);
    setSuccess("");
    setDownloadUrl("");
    removeFile();
  };

  const handleConversionChange = (e) => {
    setConversionType(e.target.value);
    resetState();
  };

  const handleConvert = async () => {
    if (!file) {
      alert("Please select a file.");
      return;
    }

    setLoading(true);
    setErrors([]);
    setSuccess("");
    setDownloadUrl("");

    const formData = new FormData();
    formData.append("file", file);

    let endpoint = "";

    if (conversionType === "excelToPostman") {
      endpoint = "http://localhost:7979/convert";
      formData.append("collectionName", collectionName);
    } else {
      endpoint = "http://localhost:7979/postman-to-template";
    }

    try {
      const response = await fetch(endpoint, {
        method: "POST",
        body: formData,
      });

      const data = await response.json();

      if (data.errors && data.errors.length > 0) {
        setErrors(data.errors);
      } else {
        setSuccess(
          conversionType === "excelToPostman"
            ? "Postman Collection generated successfully!"
            : "Excel Template generated successfully!",
        );

        setDownloadUrl(data.downloadUrl);
      }
    } catch (err) {
      setErrors(["Unable to connect to Python server."]);
      console.error(err);
    }

    setLoading(false);
  };

  return (
    <div className="pageWithActionsconvert">
      <div className="converter-container">
        <h2 className="converter-title">Template Converter</h2>

        <div className="form-group">
          <label>Conversion Type</label>

          <select
            className="text-input"
            value={conversionType}
            onChange={handleConversionChange}
          >
            <option value="excelToPostman">
              API Template → Postman Collection Converter
            </option>

            <option value="postmanToTemplate">
              Postman Collection → API Template Converter
            </option>
          </select>
        </div>

        {conversionType === "excelToPostman" && (
          <div className="form-group">
            <label>Collection Name</label>

            <input
              type="text"
              className="text-input"
              value={collectionName}
              onChange={(e) => setCollectionName(e.target.value)}
            />
          </div>
        )}

        <div className="form-group">
          <label>
            {conversionType === "excelToPostman"
              ? "Select Excel File"
              : "Select Postman Collection (.json)"}
          </label>

          <input
            type="file"
            accept={
              conversionType === "excelToPostman" ? ".xlsx,.xls" : ".json"
            }
            ref={fileInputRef}
            onChange={(e) => setFile(e.target.files[0])}
            className="file-input"
          />
        </div>
        <div className="info-box">
          {conversionType === "excelToPostman" ? (
            <>
              <strong>Note:</strong>
              <ul>
                <li>Upload an API Template Excel file (.xlsx or .xls).</li>
                <li>
                  Ensure the template contains the required columns. [TestName,
                  Method, URL, Headers, Payload]
                </li>
                <li>
                  Enter a collection name for the generated Postman Collection.
                </li>
                <li>
                  The generated collection can be imported directly into
                  Postman.
                </li>
              </ul>
            </>
          ) : (
            <>
              <strong>Note:</strong>
              <ul>
                <li>
                  Upload a Postman Collection (.json) exported from Postman.
                </li>
                <li>Only Postman Collection JSON format is supported.</li>
                <li>An Excel API Template will be generated automatically.</li>
                <li>No collection name is required for this conversion.</li>
              </ul>
            </>
          )}
        </div>
        {file && (
          <div className="selected-file">
            Selected File:
            <br />
            <strong>{file.name}</strong>
            <button
              type="button"
              className="remove-file-btn"
              onClick={removeFile}
              aria-label="Remove selected file"
            >
              ✕
            </button>
          </div>
        )}

        <button
          onClick={handleConvert}
          disabled={!file || loading}
          className="convert-button"
        >
          {loading ? "Converting..." : "Upload & Convert"}
        </button>

        {success && <div className="success-box">{success}</div>}

        {errors.length > 0 && (
          <div className="error-box">
            <h3>Validation Errors</h3>

            <ul>
              {errors.map((err, index) => (
                <li key={index}>{err}</li>
              ))}
            </ul>
          </div>
        )}

        {downloadUrl && (
          <div className="download-section">
            <a
              href={downloadUrl}
              target="_blank"
              rel="noreferrer"
              className="download-button"
            >
              {conversionType === "excelToPostman"
                ? "Download Postman Collection"
                : "Download Excel Template"}
            </a>
          </div>
        )}
      </div>
    </div>
  );
}
