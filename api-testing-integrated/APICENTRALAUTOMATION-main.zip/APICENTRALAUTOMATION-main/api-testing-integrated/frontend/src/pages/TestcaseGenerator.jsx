import React, { useMemo, useRef, useState, useEffect } from "react";

import "../styles/testcasegenerator.css";

/* ======================================================
   TYPES
====================================================== */

const TEST_TYPES = [
  "Test Case Generation",
  // "Modification of Testcases",
  // "Prioritization of Testcases",
];

/* ======================================================
   TEMPLATE MAPPING / as we are not using templates then modules is added
====================================================== */

const DEFAULT_MODULES = [
  "FT",
  "FLD",
  "TBL",
  "SRCH",
  "DDL",
  "RBP",
  "CALC",
  "UI",
];

// const TEMPLATE_MAPPING = {
//   "Test Case Generation": ["BFRD", "API SPEC", "USER STORY"],

//   // "Modification of Testcases": [
//   //   "EXISTING TESTCASES",
//   //   "CHANGE REQUEST",
//   //   "UPDATED FILES",
//   // ],

//   // "Prioritization of Testcases": [
//   //   "RISK MATRIX",
//   //   "BUSINESS PRIORITY",
//   //   "DEFECT HISTORY",
//   //   "EXECUTION HISTORY",
//   // ],
// };

const DOCUMENTS = [
  {
    name: "Document",
    url: "/docs/",
    // available: false,
  },
];
/* ======================================================
   OUTPUT FORMAT
====================================================== */

const OUTPUT_FORMATS = ["Azure DevOps Format (xlsx Importable)."];

/* ======================================================
   VALID FILE TYPES
====================================================== */

const ALLOWED_EXTENSIONS = [
  "xlsx",
  "xls",
  "docx",
  "pdf",
  "json",
  "yaml",
  "txt",
];

const MAX_FILE_SIZE_MB = 25;

/* ======================================================
   APP
====================================================== */

export default function App() {
  const fileInputRef = useRef(null);
  const dropdownRef = useRef(null);

  /* ======================================================
     STATES
  ====================================================== */

  const [selectedType, setSelectedType] = useState(
    localStorage.getItem("selectedType") || "",
  );

  // const [selectedTemplates, setSelectedTemplates] = useState(
  //   JSON.parse(localStorage.getItem("selectedTemplates") || "[]"),
  // );
  const [context, setContext] = useState(localStorage.getItem("context") || "");
  const [uploadedFiles, setUploadedFiles] = useState([]);

  const [status, setStatus] = useState("");

  const [showDropdown, setShowDropdown] = useState(false);

  const [busy, setBusy] = useState(false);

  const [reportUrl, setReportUrl] = useState("");

  const [logs, setLogs] = useState([]);

  const [runId, setRunId] = useState(null);

  const [progressMessage, setProgressMessage] = useState("");

  const [showFiles, setShowFiles] = useState(false);

  const [summary, setSummary] = useState(null);

  const [retryPayload, setRetryPayload] = useState(null);

  const [healthStatus, setHealthStatus] = useState("Checking backend...");

  const [selectedFormats, setSelectedFormats] = useState([
    "Azure DevOps Format (xlsx Importable).",
  ]);

  /* ======================================================
     CURRENT TEMPLATES
  ====================================================== */

  // const currentTemplates = TEMPLATE_MAPPING[selectedType] || [];

  /* ======================================================
     SESSION STORAGE
  ====================================================== */

  // useEffect(() => {
  //   localStorage.setItem("selectedType", selectedType);

  //   localStorage.setItem(
  //     "selectedTemplates",
  //     JSON.stringify(selectedTemplates),
  //   );
  // }, [selectedType, selectedTemplates]);

  useEffect(() => {
    localStorage.setItem("selectedType", selectedType);
    localStorage.setItem("context", context);
  }, [selectedType, context]);

  /* ======================================================
     CONTEXT STORAGE
  ====================================================== */

  useEffect(() => {
    const textarea = document.querySelector("textarea");

    if (textarea) {
      textarea.style.height = "auto";
      textarea.style.height = `${textarea.scrollHeight}px`;
    }
  }, [context]);

  /* ======================================================
     HEALTH CHECK
  ====================================================== */

  useEffect(() => {
    const checkHealth = async () => {
      try {
        const response = await fetch("http://192.168.3.173:4180/api/v1/health");

        if (!response.ok) {
          throw new Error();
        }

        setHealthStatus("Connected to AI Engine");
      } catch {
        setHealthStatus("Backend unavailable");
      }
    };

    checkHealth();
  }, []);

  /* ======================================================
     OUTSIDE CLICK CLOSE
  ====================================================== */

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setShowDropdown(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  /* ======================================================
     REAL TIME LOGS
  ====================================================== */

  useEffect(() => {
    if (!runId) return;

    const interval = setInterval(async () => {
      try {
        const response = await fetch(
          `http://192.168.3.173:4180/api/v1/testcases/jobs/${runId}`,
        );

        if (!response.ok) {
          clearInterval(interval);
          return;
        }

        const data = await response.json();

        // Stop polling once completed
        if (data.status === "COMPLETED") {
          clearInterval(interval);
        }

        // If backend exposes logs
        if (Array.isArray(data.logs)) {
          setLogs(data.logs);
        }
      } catch {
        clearInterval(interval);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [runId]);

  /* ======================================================
     VALIDATIONS
  ====================================================== */

  const validateBeforeSend = () => {
    if (!selectedType) {
      setStatus("Please select testcase type.");
      return false;
    }

    // if (selectedTemplates.length === 0) {
    //   setStatus("Please select at least one template.");
    //   return false;
    // }

    if (uploadedFiles.length === 0) {
      setStatus("Please upload at least one file.");
      return false;
    }

    if (!context.trim()) {
      setStatus("Please enter context.");
      return false;
    }

    return true;
  };

  /* ======================================================
     TEMPLATE SELECTION
  ====================================================== */

  // const handleTemplateSelection = (template) => {
  //   setSelectedTemplates((prev) => {
  //     if (prev.includes(template)) {
  //       return prev.filter((item) => item !== template);
  //     }

  //     return [...prev, template];
  //   });
  // };

  /* ======================================================
     FORMAT SELECTION
  ====================================================== */

  const handleFormatSelection = (format) => {
    setSelectedFormats([format]);
  };

  /* ======================================================
     HANDLE FILES
  ====================================================== */

  const handleFiles = (files) => {
    if (!files || files.length === 0) return;

    const incomingFiles = Array.from(files);

    setUploadedFiles((prev) => {
      let updatedFiles = [...prev];

      let addedCount = 0;
      let skipped = [];

      for (const file of incomingFiles) {
        const extension = file.name.split(".").pop()?.toLowerCase();

        if (!ALLOWED_EXTENSIONS.includes(extension)) {
          skipped.push(`${file.name} (unsupported type)`);
          continue;
        }

        const sizeMB = file.size / (1024 * 1024);

        if (sizeMB > MAX_FILE_SIZE_MB) {
          skipped.push(`${file.name} (exceeds 25MB)`);
          continue;
        }

        const duplicate = updatedFiles.some((f) => f.name === file.name);

        if (duplicate) {
          skipped.push(`${file.name} (duplicate)`);
          continue;
        }

        updatedFiles.push(file);
        addedCount++;
      }

      // STATUS UPDATE (single clean update)
      if (addedCount > 0 && skipped.length === 0) {
        setStatus(`${addedCount} file(s) added.`);
      } else if (addedCount > 0 && skipped.length > 0) {
        setStatus(`${addedCount} file(s) added, ${skipped.length} skipped.`);
      } else if (skipped.length > 0) {
        setStatus(`Files skipped: ${skipped.length}`);
      }

      return updatedFiles;
    });
  };

  /* ======================================================
     REMOVE FILE
  ====================================================== */

  const removeFile = (fileName) => {
    setUploadedFiles((prev) => {
      const updated = prev.filter((file) => file.name !== fileName);

      // Update status immediately after removal
      if (updated.length === 0) {
        setStatus("No files selected.");
      } else {
        setStatus(`${updated.length} file(s) selected.`);
      }

      return updated;
    });
  };

  /* ======================================================
     FILE EVENTS
  ====================================================== */

  const onFileChange = (event) => {
    handleFiles(event.target.files);
  };

  const handleDrag = (event) => {
    event.preventDefault();
    event.stopPropagation();
  };

  const handleDrop = (event) => {
    event.preventDefault();
    event.stopPropagation();

    const files = event.dataTransfer.files;

    handleFiles(files);
  };

  /* ======================================================
     GENERATE TEST CASES
  ====================================================== */

  const generateTestCases = async (existingPayload = null) => {
    setStatus("");

    if (!existingPayload && !validateBeforeSend()) {
      return;
    }

    try {
      setBusy(true);

      setProgressMessage("Generating AI Testcases...");

      setReportUrl("");

      setSummary(null);

      setLogs([]);

      const formData = existingPayload || new FormData();

      // if (!existingPayload) {
      //   formData.append("type", selectedType);

      //   selectedFormats.forEach((format) => {
      //     formData.append("outputFormats", format);
      //   });

      //   selectedTemplates.forEach((template) => {
      //     formData.append("templates", template);
      //   });

      //   uploadedFiles.forEach((file) => {
      //     formData.append("files", file);
      //   });
      // }

      // setRetryPayload(formData);
      if (!existingPayload) {
        // const request = {
        //     provider: null,
        //     model: null,
        //     context: selectedType,
        //     requirementText: null,
        //     useTemplate: selectedTemplates.length > 0,
        //     modules: selectedTemplates,
        //     inputMode: "FILE_API",
        //     tag: selectedFormats[0]
        // };

        const request = {
          provider: "gemini",
          context,
          inputMode: "FILE_API",
          useTemplate: true,
          modules: DEFAULT_MODULES,
          tag: selectedFormats[0],
        };

        formData.append("request", JSON.stringify(request));

        uploadedFiles.forEach((file) => {
          formData.append("files", file);
        });

        setRetryPayload(formData);
      }
      /*
        API TIMEOUT
      */

      const controller = new AbortController();

      const timeoutId = setTimeout(() => {
        controller.abort();
      }, 180000);

      /*
        BACKEND API
      */

      const response = await fetch(
        "http://192.168.3.173:4180/api/v1/testcases/generate",
        {
          method: "POST",
          body: formData,
          signal: controller.signal,
        },
      );

      clearTimeout(timeoutId);

      if (!response.ok) {
        const errorMessage = await response.text();

        throw new Error(errorMessage || "Generation failed");
      }

      const result = await response.json();

      // Store Job Id
      if (result.jobId) {
        setRunId(result.jobId);
      }

      // Download generated CSV
      setProgressMessage("Preparing Download...");

      const downloadResponse = await fetch(
        `http://192.168.3.173:4180/api/v1/testcases/jobs/${result.jobId}/download`,
      );

      if (!downloadResponse.ok) {
        throw new Error("Failed to download generated file.");
      }

      const blob = await downloadResponse.blob();

      const url = window.URL.createObjectURL(blob);

      const a = document.createElement("a");

      a.href = url;

      a.download = result.outputFile || "generated-testcases.csv";

      document.body.appendChild(a);

      a.click();

      document.body.removeChild(a);

      setReportUrl(url);

      // Summary
      setSummary({
        total: result.testCaseCount,
        format: selectedFormats[0],
      });

      setStatus("Test cases generated successfully.");
    } catch (error) {
      if (error.name === "AbortError") {
        setStatus("Request timeout. Please retry.");
      } else {
        setStatus(error.message || "Failed to generate test cases.");
      }
    } finally {
      setBusy(false);

      setProgressMessage("");
    }
  };

  /* ======================================================
     BUTTON ENABLE
  ====================================================== */

  const canGenerate = useMemo(() => {
    return (
      selectedType &&
      // selectedTemplates.length > 0 &&
      context.trim() &&
      uploadedFiles.length > 0 &&
      !busy
    );
  }, [selectedType, context, uploadedFiles, busy]);

  /* ======================================================
     Documents 
  ====================================================== */
  const [showDocsModal, setShowDocsModal] = useState(false);

  // Download Documents from the Document Function
  const handleDocumentDownload = async (doc) => {
    try {
      const fileUrl = `${window.location.origin}${doc.url}`;
      const response = await fetch(fileUrl, { cache: "no-store" });

      if (!response.ok) {
        setStatus(`Document not found: ${doc.name} (${response.status})`);
        return;
      }

      const contentType = response.headers.get("content-type") || "";

      // Block HTML fallback pages
      if (contentType.includes("text/html")) {
        setStatus(`Document path is wrong or file is missing: ${doc.name}`);
        return;
      }

      const blob = await response.blob();

      if (!blob || blob.size === 0) {
        setStatus(`Document is empty or unavailable: ${doc.name}`);
        return;
      }

      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = doc.url.split("/").pop() || doc.name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);

      setStatus(`Document downloaded: ${doc.name}`);
    } catch (error) {
      setStatus(`Unable to download document: ${doc.name}`);
    }
  };

  /* ======================================================
     UI
  ====================================================== */

  return (
    <div className="pageWithActionstestcase">
      <div className="topActionsBar">
        <button className="documentsBtn" onClick={() => setShowDocsModal(true)}>
          Documents
        </button>
      </div>
      <div className="cardtestcase">
        <h1>AI Test Case Generator</h1>

        <p className="subtitle">
          Select Type → Enter Context → Upload Files → Generate
        </p>

        {/* HEALTH */}

        <div
          className={`healthBar ${
            healthStatus === "Connected to AI Engine"
              ? "healthSuccess"
              : "healthError"
          }`}
        >
          {healthStatus}
        </div>

        {/* TYPE */}

        <div className="section">
          <label>
            Select Type <span className="required">*</span>
          </label>
          <select
            value={selectedType}
            disabled={busy}
            onChange={(e) => {
              setSelectedType(e.target.value);

              setUploadedFiles([]);
              setContext("");
              // setSelectedTemplates([]);
            }}
          >
            <option value="">-- Select Type --</option>

            {TEST_TYPES.map((type, index) => (
              <option key={index} value={type}>
                {type}
              </option>
            ))}
          </select>
        </div>

        {/* TEMPLATES */}

        {selectedType && (
          <>
            {/* <div className="section">
              <label>Technical Template Files</label>

              <div className="multiSelectDropdown" ref={dropdownRef}>
                <div
                  className="dropdownHeader"
                  onClick={() => !busy && setShowDropdown((prev) => !prev)}
                >
                  {selectedTemplates.length > 0
                    ? selectedTemplates.join(", ")
                    : "Select Templates"}
                </div>

                {showDropdown && (
                  <div className="dropdownOptions">
                    {currentTemplates.map((template, index) => (
                      <label key={index} className="dropdownOption">
                        <input
                          type="checkbox"
                          checked={selectedTemplates.includes(template)}
                          onChange={() => handleTemplateSelection(template)}
                        />

                        {template}
                      </label>
                    ))}
                  </div>
                )}
              </div>
            </div> */}

            {/* FILES */}
            <div className="section">
              <label>
                Context <span className="required">*</span>
              </label>

              <textarea
                placeholder="Enter Context"
                value={context}
                disabled={busy}
                maxLength={1000}
                rows={3}
                onChange={(e) => {
                  setContext(e.target.value);

                  // Auto height adjustment
                  e.target.style.height = "auto";
                  e.target.style.height = `${e.target.scrollHeight}px`;
                }}
              />

              <div className="charCount">{context.length}/1000</div>
            </div>

            <div className="section">
              <label>Upload Input Files</label>

              <div
                className="dropzone"
                onDragEnter={handleDrag}
                onDragOver={handleDrag}
                onDrop={handleDrop}
                onClick={() => !busy && fileInputRef.current?.click()}
                style={{
                  cursor: busy ? "not-allowed" : "pointer",
                }}
              >
                <p>Drag & Drop files here or Click to Browse</p>

                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  disabled={busy}
                  style={{
                    display: "none",
                  }}
                  onChange={onFileChange}
                />
              </div>
            </div>

            {/* View files*/}
            <div className="section">
              <button
                className="viewFilesBtn"
                onClick={() => setShowFiles((prev) => !prev)}
                disabled={uploadedFiles.length === 0}
              >
                {showFiles
                  ? "Hide Files"
                  : `View Files (${uploadedFiles.length})`}
              </button>
            </div>
            {showFiles && (
              <div className="section">
                <label>Selected Files</label>

                {uploadedFiles.length === 0 ? (
                  <p>No files selected</p>
                ) : (
                  <div className="fileListView">
                    {uploadedFiles.map((file, index) => (
                      <div key={index} className="fileRow">
                        <span className="fileName">{file.name}</span>

                        <button
                          className="removeIconBtn"
                          onClick={() => removeFile(file.name)}
                        >
                          ✕
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* OUTPUT */}

            <div className="section">
              <label>Output Format</label>

              <div className="formatCheckboxGroup">
                {OUTPUT_FORMATS.map((format, index) => (
                  <label key={index} className="formatCheckboxItem">
                    <input
                      type="checkbox"
                      checked={selectedFormats.includes(format)}
                      disabled={busy}
                      onChange={() => handleFormatSelection(format)}
                    />

                    <span>{format}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* LOADING */}

            {busy && (
              <div className="loadingBox">
                <div className="spinner"></div>

                <div>{progressMessage}</div>
              </div>
            )}

            {/* LOGS */}
            {(logs.length > 0 || summary) && (
              <div className="executionPanel">
                <div className="executionHeader">
                  <strong>Execution Details</strong>
                </div>

                {/* LIVE LOGS */}
                <div className="logsBox">
                  <div className="logsTitle">Live Logs</div>

                  <div className="logsList">
                    {logs.length === 0 ? (
                      <div>Waiting for execution...</div>
                    ) : (
                      logs.map((log, index) => (
                        <div key={index} className="logLine">
                          ✔ {log}
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* SUMMARY INSIDE SAME BOX */}
                {summary && (
                  <div className="summaryBox">
                    <div className="logsTitle">Summary</div>

                    <p>✔ {summary.total} Testcases Generated</p>

                    <p>✔ Format: {summary.format}</p>
                  </div>
                )}
              </div>
            )}

            {/* BUTTONS */}

            <div className="buttonRow">
              <button
                className="runBtn"
                disabled={!canGenerate}
                onClick={() => generateTestCases()}
              >
                {busy ? "Generating..." : "Generate"}
              </button>

              {retryPayload && (
                <button
                  className="retryBtn"
                  disabled={busy}
                  onClick={() => generateTestCases(retryPayload)}
                >
                  Retry
                </button>
              )}
            </div>
          </>
        )}

        {/* STATUS */}

        {status && <div className="status">{status}</div>}

        {/* DOWNLOAD */}

        {reportUrl && (
          <div className="section">
            <a
              href={reportUrl}
              download="generated-testcases.csv"
              className="downloadBtn"
            >
              Download Generated Test Cases
            </a>
          </div>
        )}
      </div>

      {showDocsModal && (
        <div className="modalOverlay" onClick={() => setShowDocsModal(false)}>
          <div className="modalCard" onClick={(e) => e.stopPropagation()}>
            <div className="modalHeader">
              <h2>AI Test Case Generator Documents</h2>
              <button
                className="closeModalBtn"
                onClick={() => setShowDocsModal(false)}
              >
                ✕
              </button>
            </div>

            <div className="documentsList">
              {DOCUMENTS.map((doc, index) => (
                <div className="documentRow" key={index}>
                  <span>{doc.name}</span>
                  <button
                    type="button"
                    className="downloadDocBtn"
                    // disabled={!doc.available}
                    onClick={() => handleDocumentDownload(doc)}
                  >
                    Download
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
