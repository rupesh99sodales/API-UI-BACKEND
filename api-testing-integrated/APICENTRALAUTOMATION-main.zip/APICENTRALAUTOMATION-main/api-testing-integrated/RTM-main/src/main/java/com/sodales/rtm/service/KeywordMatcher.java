package com.sodales.rtm.service;

import java.util.*;

/**
 * Keyword-based matcher. Scores a user story against a test case using tokens
 * from their TITLES, their DESCRIPTIONS, and their TAGS. Signals are weighted by
 * how discriminative they are:
 *
 *   shared title word  x2   (titles are concise and meaningful)
 *   shared tag         x2   (tags are deliberate labels)
 *   shared other word  x1   (description / acceptance-criteria - richer but noisier)
 *
 * "Other" words are title-independent: a word already counted as a shared title
 * word is not counted again. This lets descriptions add real signal (a test whose
 * title shares nothing with a story can still match via description) without
 * letting common words like "status"/"claim" over-link on their own.
 *
 * Transparent and deterministic; matched words and tags are returned as evidence.
 */
public final class KeywordMatcher {

    public static final int TITLE_WEIGHT = 2;
    public static final int TAG_WEIGHT   = 2;
    public static final int OTHER_WEIGHT = 1;

    private static final Set<String> STOPWORDS = Set.of(
            "the","a","an","and","or","of","to","for","with","on","in","is","are",
            "be","when","then","given","should","that","this","will","can","all","as",
            "at","by","from","it","its","into","within","up","per","no","not","if","so",
            "than","was","were","has","have","had","but","which","via","using","use",
            "test","case","tests","cases","story","stories","user","shall","must",
            "verify","verifies","verified","ensure","check","system","data");

    public record Result(int score, List<String> words, List<String> tags) {
        public boolean matches(int threshold) { return score >= threshold; }
    }

    private KeywordMatcher() { }

    public static Result score(String storyTitle, String storyOther, String storyTags,
                               String testTitle, String testOther, String testTags) {

        Set<String> stTitle = tokenize(storyTitle);
        Set<String> tTitle  = tokenize(testTitle);
        Set<String> stAll = new HashSet<>(stTitle); stAll.addAll(tokenize(storyOther));
        Set<String> tAll  = new HashSet<>(tTitle);  tAll.addAll(tokenize(testOther));

        Set<String> sharedTitle = intersect(stTitle, tTitle);
        Set<String> sharedAll   = intersect(stAll, tAll);
        Set<String> sharedOther = new HashSet<>(sharedAll); sharedOther.removeAll(sharedTitle);
        Set<String> sharedTags  = intersect(tags(storyTags), tags(testTags));

        int score = sharedTitle.size() * TITLE_WEIGHT
                  + sharedOther.size() * OTHER_WEIGHT
                  + sharedTags.size()  * TAG_WEIGHT;

        List<String> words = new ArrayList<>(sharedAll);
        List<String> tagList = new ArrayList<>(sharedTags);
        Collections.sort(words);
        Collections.sort(tagList);
        return new Result(score, words, tagList);
    }

    static Set<String> tokenize(String text) {
        if (text == null || text.isBlank()) return Set.of();
        Set<String> out = new HashSet<>();
        for (String raw : text.toLowerCase(Locale.ROOT).split("[^a-z0-9]+")) {
            if (raw.length() < 3) continue;
            if (STOPWORDS.contains(raw)) continue;
            out.add(stem(raw));
        }
        return out;
    }

    static Set<String> tags(String tagField) {
        if (tagField == null || tagField.isBlank()) return Set.of();
        Set<String> out = new HashSet<>();
        for (String t : tagField.split("[;,]")) {
            String v = t.trim().toLowerCase(Locale.ROOT);
            if (!v.isEmpty()) out.add(v);
        }
        return out;
    }

    private static String stem(String w) {
        if (w.length() > 4 && w.endsWith("es")) return w.substring(0, w.length() - 2);
        if (w.length() > 3 && w.endsWith("s") && !w.endsWith("ss")) return w.substring(0, w.length() - 1);
        return w;
    }

    private static Set<String> intersect(Set<String> a, Set<String> b) {
        Set<String> r = new HashSet<>(a);
        r.retainAll(b);
        return r;
    }
}
