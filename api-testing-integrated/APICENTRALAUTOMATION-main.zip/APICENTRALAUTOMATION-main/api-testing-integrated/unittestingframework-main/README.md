# No Code Unit Testing Framework

## From Excel Templates to Intelligent API Tests, No Code Required.

QUALITY is an intelligent no-code testing framework that transforms structured Excel templates into executable API unit and integration test cases. It bridges the gap between business-readable test logic and automated execution by parsing Excel sheets, generating API test payloads, assertions, and workflows, all without manual scripting.

### Prerequisites
Java 21.0.2
Maven apache-maven-3.9.6
Rest of the libraries are handled as a part of maven dependancies.

### How to Run?
Clone this repository https://github.com/sohambpatel/QUALITY.git

Download all the dependancies mvn clean install -U

Running the main method src/main/java/org/api/ApiTests.java

Make sure to update the template path at List tests = ExcelReader.readTestCases("src/main/resources/api_test_data.xlsx");

Sample template with oauth given here src/main/resources/api_test_data_OauthSample.xlsx

Sample template without oauth given here src/main/resources/api_test_data.xlsx

Make sure to update the framework properties accordingly src/main/resources/framework.properties
