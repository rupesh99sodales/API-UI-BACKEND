package org.sodales;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Variables are scoped to this handler instance (one per TestRunContext). */
public class GlobalVariableHandler extends JSONFilePathHandler {
    private final Map<String, String> variables = new ConcurrentHashMap<>();

    public void setGlobalVariable(String jsonorxmlpath, String globalvariablename, String contenttoread, String xmlorjson) {
        try {
            if (globalvariablename == null || globalvariablename.isBlank()) throw new IllegalArgumentException("Global variable name is required");
            if (jsonorxmlpath == null || jsonorxmlpath.equalsIgnoreCase("na")) return;
            String value;
            if ("json".equalsIgnoreCase(xmlorjson)) value = readJsonPath(contenttoread, jsonorxmlpath);
            else if ("xml".equalsIgnoreCase(xmlorjson)) value = readXmlPath(contenttoread, jsonorxmlpath);
            else throw new IllegalArgumentException("Variable source must be JSON or XML");
            if (value == null) throw new IllegalArgumentException("No value found for global variable: " + globalvariablename);
            variables.put(globalvariablename, value);
            LogCollector.log("Global variable captured: " + globalvariablename + " (value hidden)");
        } catch (Exception e) {
            LogCollector.log("Unable to set global variable '" + globalvariablename + "': " + e.getMessage());
            throw new IllegalArgumentException("Unable to set global variable '" + globalvariablename + "'. Check the JSON/XML path and response content.", e);
        }
    }

    public String globalvariablevaluereplacer(String body) {
        if (body == null) return null;
        String result = body;
        for (Map.Entry<String, String> entry : variables.entrySet()) result = result.replace(entry.getKey(), entry.getValue());
        return result;
    }
}
