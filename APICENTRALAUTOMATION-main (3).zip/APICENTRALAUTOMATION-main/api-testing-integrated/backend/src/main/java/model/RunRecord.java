package model;

import java.time.Instant;

public class RunRecord {
    public final TestRunContext context;
    public volatile RunStatus status = RunStatus.QUEUED;
    public volatile String errorCode;
    public volatile String errorMessage;
    public final Instant createdAt = Instant.now();
    public volatile Instant startedAt;
    public volatile Instant completedAt;

    public RunRecord(TestRunContext context) { this.context = context; }
}
