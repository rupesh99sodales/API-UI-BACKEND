package com.sodales.rtm.csv;

import java.util.List;
import java.util.Map;

/** A parsed CSV: the original header names plus rows keyed by lower-cased header. */
public record CsvTable(List<String> headers, List<Map<String, String>> rows) {

    /** First header (case-insensitive) that matches any candidate, or null. */
    public String resolveHeader(String... candidates) {
        for (String c : candidates) {
            for (String h : headers) {
                if (h != null && h.trim().equalsIgnoreCase(c.trim())) {
                    return h;
                }
            }
        }
        return null;
    }

    /** Value for a resolved header from a row (row keys are lower-cased). */
    public static String value(Map<String, String> row, String header) {
        if (header == null) return null;
        return row.get(header.toLowerCase());
    }
}
