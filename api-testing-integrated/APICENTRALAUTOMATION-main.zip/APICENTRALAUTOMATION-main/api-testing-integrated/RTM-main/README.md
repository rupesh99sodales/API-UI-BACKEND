# rtm-ado-service

A small, **database-free** Spring Boot REST service. Upload **one or more** Azure
DevOps user-story CSV exports and **one or more** test-case CSV exports, and
download **one** Requirements Traceability Matrix workbook.

Test cases are mapped to user stories by **keyword matching** across
**title + description + tags** on both sides. Every suggested link is written to a
**Matches** sheet with its score and the exact words/tags that triggered it, so
each mark is auditable. Coverage is live — a story with no marks is flagged
**RED (UNCOVERED)** and flips to COVERED as marks are confirmed.

Everything runs in memory. Nothing is stored.

## How the mapping works (hybrid, decided per test case)
1. **Explicit link present → use it (authoritative).** If a test case has a link
   value in a mapping column — auto-detected among `User Story ID`, `Tested By`,
   `Requirement ID`, `Parent`, `Tested User Story`, … (or set `testLinkColumn`) —
   that link is used directly. A cell may hold several story IDs (`101; 105`).
   These appear on the Matches sheet with **Source = Link**.
2. **No link → keyword matching (suggested).** Otherwise the test case is matched
   by keyword overlap of **title + description + tags**, weighted:

       shared title word × 2     shared tag × 2     shared description word × 1

   Description words count for less than titles/tags, so descriptions add signal
   without letting common words over-link. A pair links at the threshold
   (`minScore`, default **3**). These appear with **Source = Keyword** and a score.

Both sides accept **multiple files** — repeat the `stories` / `testcases` form key.
All files are merged and de-duplicated by ID; link detection is per file, so a mix
of linked and unlinked test-case files is handled correctly. Coverage counts marks,
so any suggested link can be confirmed or cleared by hand.

## Run
```bash
mvn spring-boot:run
```
Starts on `http://localhost:8080`. No database, no other setup.

## Try it with the sample data (2 story files + 2 test files)
```bash
BASE=http://localhost:8080
curl -OJ -X POST "$BASE/api/rtm/generate" \
  -F stories=@sample-data/UserStories_ProjectA.csv \
  -F stories=@sample-data/UserStories_ProjectB.csv \
  -F testcases=@sample-data/TestCases_Suite1.csv \
  -F testcases=@sample-data/TestCases_Suite2.csv
# tune strictness:  add  -F minScore=3
```
Repeat the `stories=@...` / `testcases=@...` flags for as many files as you like —
they are merged and de-duplicated by ID into one workbook.

```bash
# Inspect matches (with evidence) as JSON, no download:
curl -X POST "$BASE/api/rtm/preview" -F stories=@... -F testcases=@...
```

## Endpoints
| Method | Path                | Body (multipart/form-data)                   | Returns |
|--------|---------------------|----------------------------------------------|---------|
| POST   | `/api/rtm/generate` | `stories` (1+), `testcases` (1+), `minScore?`| `traceability.xlsx` download |
| POST   | `/api/rtm/preview`  | same                                         | JSON: counts + matches with evidence |

### Optional overrides (form fields)
`minScore` (int, default 3) tunes keyword strictness. Column names auto-detect from
ADO defaults; override only if yours differ:

| Param | Applies to | Auto-detected from |
|-------|-----------|--------------------|
| `storyIdColumn` / `testIdColumn`      | stories / tests | `ID`, `Work Item ID` |
| `storyTitleColumn` / `testTitleColumn`| stories / tests | `Title` |
| `storyStateColumn`                    | stories | `State`, `Status` |
| `storyAcColumn`                       | stories | `Acceptance Criteria` |
| `storyDescColumn` / `testDescColumn`  | stories / tests | `Description`, `Details`, `Summary`, `Steps` |
| `testLinkColumn`                      | tests | `User Story ID`, `Tested By`, `Parent`, … (explicit mapping) |
| `storyTagColumn` / `testTagColumn`    | stories / tests | `Tags` |

## The Excel output (single workbook)
- **Summary** — files merged, totals, keyword-match count, unmatched test cases,
  live coverage %, mapping mode, a review note, and a red legend.
- **RTM Matrix** — user stories as rows (ID, Title, Acceptance Criteria, State,
  Linked Count, Coverage), test cases as columns. Keyword matches are pre-marked
  `X`. `Linked Count`/`Coverage` are formulas; conditional formatting turns a row
  red while UNCOVERED, green once COVERED. You can add/remove `X` by hand.
- **Matches** — every link with Source (Link/Keyword), Score, and Evidence, so
  each mark can be reviewed. Filterable.
- **Test Cases** — the merged list of every test case (decodes the matrix column IDs).

## Sample files
`sample-data/` holds two story exports and two test exports, all with `Tags`.
The keyword pass links 7 pairs (incl. a tag-only match, 5004→102), leaves test
5008 unmatched (an orphan), and leaves story 106 uncovered (red).

## Notes
- Not compiled in the authoring environment (no Maven Central access there); run
  `mvn` once locally to pull Spring Boot + POI. Plain Spring Boot 3 / Java 17.
- Matching is O(stories × test cases); fine for typical RTM sizes.
- CSV parser handles quotes, embedded commas/newlines, CRLF, and the UTF-8 BOM.
